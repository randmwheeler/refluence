class CreateAudiences < ActiveRecord::Migration
  def change
    create_table :audiences do |t|
      t.string :name
      t.integer :reach
      t.integer :relevance
      t.integer :renown
      t.string :neighborhoods

      t.timestamps
    end
  end
end
