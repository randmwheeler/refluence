class AddBrandToRelease < ActiveRecord::Migration
  def change
    add_reference :releases, :brand, index: true
  end
end
