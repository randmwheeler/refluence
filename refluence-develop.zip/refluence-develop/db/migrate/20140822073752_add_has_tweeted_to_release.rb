class AddHasTweetedToRelease < ActiveRecord::Migration
  def change
    add_column :releases, :has_tweeted, :boolean, default: false
  end
end
