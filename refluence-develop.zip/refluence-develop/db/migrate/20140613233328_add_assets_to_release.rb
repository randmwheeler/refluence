class AddAssetsToRelease < ActiveRecord::Migration
  def change
    add_column :releases, :assets, :string
  end
end
