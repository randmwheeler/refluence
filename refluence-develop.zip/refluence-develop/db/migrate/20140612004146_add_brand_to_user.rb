class AddBrandToUser < ActiveRecord::Migration
  def change
    add_reference :users, :brand, index: true
  end
end
