class AddRecommendedToSubindustry < ActiveRecord::Migration
  def change
    add_reference :releases, :audience, index: true
    add_column :audiences, :handles, :text
  end
end
