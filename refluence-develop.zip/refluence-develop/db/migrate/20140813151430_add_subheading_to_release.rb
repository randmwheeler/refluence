class AddSubheadingToRelease < ActiveRecord::Migration
  def change
    add_column :releases, :subheading, :text
  end
end
