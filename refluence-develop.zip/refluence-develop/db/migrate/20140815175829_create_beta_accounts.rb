class CreateBetaAccounts < ActiveRecord::Migration
  def change
    create_table :beta_accounts do |t|
      t.string :email, 	null: false, default: ""
      t.string :code, 	null: false, default: ""
      t.boolean :used
      t.datetime :sent_at

      t.timestamps
    end

    add_index :beta_accounts, :email, 	unique: true
    add_index :beta_accounts, :code,	unique: true
  end
end
