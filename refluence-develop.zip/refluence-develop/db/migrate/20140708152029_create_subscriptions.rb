class CreateSubscriptions < ActiveRecord::Migration
  def change
    create_table :subscriptions do |t|
      t.string :price
      t.integer :users
      t.integer :audiences
      t.integer :active_releases
      t.integer :agencies
      t.integer :brands
      t.integer :social_accounts

      t.timestamps
    end
  end
end
