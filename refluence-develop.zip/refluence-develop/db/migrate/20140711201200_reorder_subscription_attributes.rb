class ReorderSubscriptionAttributes < ActiveRecord::Migration
  def change
  	drop_table :subscriptions
    create_table :subscriptions do |t|
      t.string :name
      t.string :price
      t.integer :admins
      t.integer :delegates
      t.integer :audiences
      t.integer :active_releases
      t.integer :agencies
      t.integer :brands
      t.integer :social_accounts

      t.timestamps
    end
  end
end
