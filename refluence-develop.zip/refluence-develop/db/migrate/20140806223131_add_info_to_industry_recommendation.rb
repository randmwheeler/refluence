class AddInfoToIndustryRecommendation < ActiveRecord::Migration
  def change
    add_column :industry_recommendations, :numeric_id, :integer
    add_column :industry_recommendations, :handle, :string
    add_column :industry_recommendations, :location, :string
    add_column :industry_recommendations, :follower_count, :integer
    add_column :industry_recommendations, :following_count, :integer
    add_column :industry_recommendations, :tweet_count, :integer
    add_column :industry_recommendations, :favorites_count, :integer
    add_column :industry_recommendations, :listed_count, :integer
    add_column :industry_recommendations, :score, :decimal
  end
end
