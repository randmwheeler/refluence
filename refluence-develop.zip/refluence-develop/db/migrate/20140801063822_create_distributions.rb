class CreateDistributions < ActiveRecord::Migration
  def change
    create_table :distributions do |t|
      t.references :release, index: true
      t.datetime :start_date
      t.datetime :end_date
      t.string :time_zone

      t.timestamps
    end
  end
end
