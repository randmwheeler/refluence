class CreateAgencyImages < ActiveRecord::Migration
  def change
    create_table :agency_images do |t|
      t.references :agency, index: true

      t.timestamps
    end
  end
end
