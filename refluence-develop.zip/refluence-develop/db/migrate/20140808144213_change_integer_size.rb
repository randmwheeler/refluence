class ChangeIntegerSize < ActiveRecord::Migration
  def change
  	change_column :industry_recommendations, :numeric_id, :integer, limit: 8
  end
end
