class CreatePersonalities < ActiveRecord::Migration
  def change
    create_table :personalities do |t|
      t.references :brand
      t.references :authentication

      t.timestamps
    end
  end
end
