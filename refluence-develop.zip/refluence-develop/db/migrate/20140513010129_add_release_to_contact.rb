class AddReleaseToContact < ActiveRecord::Migration
  def change
    add_reference :contacts, :release, index: true
  end
end
