class AddSocialToDistributions < ActiveRecord::Migration
  def change
    add_column :distributions, :social, :string
  end
end
