class AddContactToRelease < ActiveRecord::Migration
  def change
    add_reference :releases, :contact, index: true
  end
end
