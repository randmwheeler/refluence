class ChangeSubscriptionName < ActiveRecord::Migration
  def change
  	remove_column :users, :subscriptions
  	add_column :users, :subscription, :integer
  end
end
