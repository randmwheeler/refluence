class RemoveSubscriptionEnumFromUser < ActiveRecord::Migration
  def up
    remove_column :users, :subscription
  end

  def down
    add_column :users, :subscription, :integer
  end
end
