class AddLevelToSubscription < ActiveRecord::Migration
  def change
    add_column :subscriptions, :level, :integer
  end
end
