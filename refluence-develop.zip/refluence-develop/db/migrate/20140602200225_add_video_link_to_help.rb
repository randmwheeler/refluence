class AddVideoLinkToHelp < ActiveRecord::Migration
  def change
    add_column :helps, :video, :string
  end
end
