class AddUserToAgencies < ActiveRecord::Migration
  def change
    add_reference :agencies, :user, index: true
    add_reference :audiences, :brand, index: true
  end
end
