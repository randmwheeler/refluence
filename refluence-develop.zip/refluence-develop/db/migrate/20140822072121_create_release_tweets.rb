class CreateReleaseTweets < ActiveRecord::Migration
  def change
    create_table :release_tweets do |t|
      t.references :release, index: true
      t.string :tweet_id
      t.string :to
      t.string :from

      t.timestamps
    end
  end
end
