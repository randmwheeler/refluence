class AddFieldsToRelease < ActiveRecord::Migration
  def change
  	add_column :releases, :copy, :text
  	add_column :releases, :url, :string
  	add_column :releases, :status, :integer
  	add_column :releases, :isTemplate, :boolean, default: false
  	add_column :releases, :headline, :string, default: ""
  end
end
