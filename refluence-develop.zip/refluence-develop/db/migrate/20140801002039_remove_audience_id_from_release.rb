class RemoveAudienceIdFromRelease < ActiveRecord::Migration
  def change
  	remove_reference :releases, :audience
  end
end
