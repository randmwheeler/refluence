class CreateContents < ActiveRecord::Migration
  def change
    create_table :contents do |t|
      t.integer :retype
      t.string :headline
      t.text :copy
      t.string :assets
      t.references :release, index: true

      t.timestamps
    end
  end
end
