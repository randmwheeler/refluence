class CreateIndustryRecommendations < ActiveRecord::Migration
  def change
    create_table :industry_recommendations do |t|
      t.references :subindustry, index: true
      t.string :name

      t.timestamps
    end
  end
end
