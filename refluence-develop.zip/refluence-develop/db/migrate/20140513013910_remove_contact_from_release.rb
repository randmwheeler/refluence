class RemoveContactFromRelease < ActiveRecord::Migration
  def change
  	remove_reference :releases, :contact
  end
end
