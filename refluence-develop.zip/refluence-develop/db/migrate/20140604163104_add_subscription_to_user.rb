class AddSubscriptionToUser < ActiveRecord::Migration
  def change
    add_column :users, :subscriptions, :integer
  end
end
