class CreateBrandsIdentities < ActiveRecord::Migration
  def change
    create_table :brands_identities, :id => false do |t|
		t.references :brand
	    t.references :identity
    end
    add_index :brands_identities, [:brand_id, :identity_id]
    add_index :brands_identities, :identity_id
  end
end
