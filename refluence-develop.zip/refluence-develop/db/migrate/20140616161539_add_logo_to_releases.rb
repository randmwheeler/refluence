class AddLogoToReleases < ActiveRecord::Migration
  def change
    add_reference :releases, :logo, index: true
  end
end
