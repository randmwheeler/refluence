class AddShortUrlToReleases < ActiveRecord::Migration
  def change
    add_column :releases, :short_url, :string
  end
end
