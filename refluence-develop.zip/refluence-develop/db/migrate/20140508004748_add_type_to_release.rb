class AddTypeToRelease < ActiveRecord::Migration
  def change
    add_column :releases, :retype, :integer
  end
end
