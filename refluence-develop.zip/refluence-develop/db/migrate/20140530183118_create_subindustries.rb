class CreateSubindustries < ActiveRecord::Migration
  def change
    create_table :subindustries do |t|
      t.string :name
      t.references :industry

      t.timestamps
    end
  end
end
