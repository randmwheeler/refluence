class AddTimeZoneToRelease < ActiveRecord::Migration
  def change
    add_column :releases, :time_zone, :string
  end
end
