class ChangeIntegerType < ActiveRecord::Migration
  def change
  	change_column :industry_recommendations, :numeric_id, :string
  end
end
