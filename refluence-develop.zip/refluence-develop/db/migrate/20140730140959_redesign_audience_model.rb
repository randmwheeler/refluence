class RedesignAudienceModel < ActiveRecord::Migration
  def change
	add_reference :audiences, :industry, index: true
	add_reference :audiences, :subindustry, index: true
	add_reference :audiences, :release, index: true
  end
end
