class AddMoreSlugs < ActiveRecord::Migration
  def change
  	add_column :users, :slug, :string, unique: true
  	add_column :releases, :slug, :string, unique: true
  	add_column :audiences, :slug, :string, unique: true
  	add_column :brands, :slug, :string, unique: true
  	add_column :agencies, :slug, :string, unique: true
  	add_column :authentications, :slug, :string, unique: true
  	add_column :personalities, :slug, :string, unique: true
  end
end
