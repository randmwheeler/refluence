class AddKeywordsToAudience < ActiveRecord::Migration
  def change
    add_column :audiences, :keywords, :string
  end
end
