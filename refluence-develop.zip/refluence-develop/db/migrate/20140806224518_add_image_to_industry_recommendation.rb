class AddImageToIndustryRecommendation < ActiveRecord::Migration
  def change
    add_column :industry_recommendations, :profile_image_url, :string
  end
end
