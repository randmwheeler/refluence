class AddImageColumnToAgencyImages < ActiveRecord::Migration
	def self.up 
		add_attachment :agency_images, :image 
	end

	def self.down 
		remove_attachment :agency_images, :image
	end
end
