class AddFieldsToUser < ActiveRecord::Migration
  def change
    add_column :users, :family_name, :string
    add_column :users, :title, :string
    add_column :users, :organization, :string
    add_column :users, :hopes, :text
  end
end
