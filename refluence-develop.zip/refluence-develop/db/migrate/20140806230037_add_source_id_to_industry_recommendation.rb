class AddSourceIdToIndustryRecommendation < ActiveRecord::Migration
  def change
    add_column :industry_recommendations, :source_id, :string
  end
end
