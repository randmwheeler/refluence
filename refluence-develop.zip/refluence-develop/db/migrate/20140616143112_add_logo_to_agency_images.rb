class AddLogoToAgencyImages < ActiveRecord::Migration
  def change
    add_column :agency_images, :logo, :boolean
  end
end
