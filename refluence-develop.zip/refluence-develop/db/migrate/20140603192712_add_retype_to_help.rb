class AddRetypeToHelp < ActiveRecord::Migration
  def change
    add_column :helps, :retype, :integer, default: 0
  end
end
