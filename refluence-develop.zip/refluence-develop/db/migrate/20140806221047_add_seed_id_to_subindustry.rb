class AddSeedIdToSubindustry < ActiveRecord::Migration
  def change
    add_column :subindustries, :seed_id, :string
  end
end
