class CreateBrandAuthentications < ActiveRecord::Migration
  def change
    create_table :brand_authentications do |t|
      t.references :brand, index: true
      t.references :identity, index: true
      t.boolean :permission
      t.integer :retype

      t.timestamps
    end
  end
end
