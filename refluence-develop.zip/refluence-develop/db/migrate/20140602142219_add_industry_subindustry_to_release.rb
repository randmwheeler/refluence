class AddIndustrySubindustryToRelease < ActiveRecord::Migration
  def change
    add_reference :releases, :industry, index: true
    add_reference :releases, :subindustry, index: true
  end
end
