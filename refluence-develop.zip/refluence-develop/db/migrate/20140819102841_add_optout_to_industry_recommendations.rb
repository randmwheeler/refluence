class AddOptoutToIndustryRecommendations < ActiveRecord::Migration
  def change
    add_column :industry_recommendations, :email, :string
    add_column :industry_recommendations, :opted_out, :boolean
  end
end
