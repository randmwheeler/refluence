class AddNameToBetaAccounts < ActiveRecord::Migration
  def change
    add_column :beta_accounts, :name, :string
  end
end
