# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20140827142832) do

  create_table "agencies", force: true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "slug"
    t.integer  "user_id"
  end

  add_index "agencies", ["user_id"], name: "index_agencies_on_user_id"

  create_table "agency_images", force: true do |t|
    t.integer  "agency_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "image_file_name"
    t.string   "image_content_type"
    t.integer  "image_file_size"
    t.datetime "image_updated_at"
    t.boolean  "logo"
  end

  add_index "agency_images", ["agency_id"], name: "index_agency_images_on_agency_id"

  create_table "audiences", force: true do |t|
    t.string   "name"
    t.integer  "reach"
    t.integer  "relevance"
    t.integer  "renown"
    t.string   "neighborhoods"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "slug"
    t.integer  "brand_id"
    t.text     "handles"
    t.integer  "industry_id"
    t.integer  "subindustry_id"
    t.integer  "release_id"
    t.string   "keywords"
  end

  add_index "audiences", ["brand_id"], name: "index_audiences_on_brand_id"
  add_index "audiences", ["industry_id"], name: "index_audiences_on_industry_id"
  add_index "audiences", ["release_id"], name: "index_audiences_on_release_id"
  add_index "audiences", ["subindustry_id"], name: "index_audiences_on_subindustry_id"

  create_table "authentications", force: true do |t|
    t.integer  "user_id"
    t.string   "provider"
    t.string   "uid"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "slug"
  end

  create_table "beta_accounts", force: true do |t|
    t.string   "email",      default: "", null: false
    t.string   "code",       default: "", null: false
    t.boolean  "used"
    t.datetime "sent_at"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "name"
  end

  add_index "beta_accounts", ["code"], name: "index_beta_accounts_on_code", unique: true
  add_index "beta_accounts", ["email"], name: "index_beta_accounts_on_email", unique: true

  create_table "brand_authentications", force: true do |t|
    t.integer  "brand_id"
    t.integer  "identity_id"
    t.boolean  "permission"
    t.integer  "retype"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "brand_authentications", ["brand_id"], name: "index_brand_authentications_on_brand_id"
  add_index "brand_authentications", ["identity_id"], name: "index_brand_authentications_on_identity_id"

  create_table "brands", force: true do |t|
    t.string   "name"
    t.integer  "agency_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "slug"
  end

  create_table "brands_identities", id: false, force: true do |t|
    t.integer "brand_id"
    t.integer "identity_id"
  end

  add_index "brands_identities", ["brand_id", "identity_id"], name: "index_brands_identities_on_brand_id_and_identity_id"
  add_index "brands_identities", ["identity_id"], name: "index_brands_identities_on_identity_id"

  create_table "contacts", force: true do |t|
    t.string   "name"
    t.string   "phone"
    t.string   "fax"
    t.string   "email"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "release_id"
  end

  add_index "contacts", ["release_id"], name: "index_contacts_on_release_id"

  create_table "contents", force: true do |t|
    t.integer  "retype"
    t.string   "headline"
    t.text     "copy"
    t.string   "assets"
    t.integer  "release_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "contents", ["release_id"], name: "index_contents_on_release_id"

  create_table "distributions", force: true do |t|
    t.integer  "release_id"
    t.datetime "start_date"
    t.datetime "end_date"
    t.string   "time_zone"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "social"
  end

  add_index "distributions", ["release_id"], name: "index_distributions_on_release_id"

  create_table "friendly_id_slugs", force: true do |t|
    t.string   "slug",                      null: false
    t.integer  "sluggable_id",              null: false
    t.string   "sluggable_type", limit: 50
    t.string   "scope"
    t.datetime "created_at"
  end

  add_index "friendly_id_slugs", ["slug", "sluggable_type", "scope"], name: "index_friendly_id_slugs_on_slug_and_sluggable_type_and_scope", unique: true
  add_index "friendly_id_slugs", ["slug", "sluggable_type"], name: "index_friendly_id_slugs_on_slug_and_sluggable_type"
  add_index "friendly_id_slugs", ["sluggable_id"], name: "index_friendly_id_slugs_on_sluggable_id"
  add_index "friendly_id_slugs", ["sluggable_type"], name: "index_friendly_id_slugs_on_sluggable_type"

  create_table "helps", force: true do |t|
    t.string   "name"
    t.text     "content"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "video"
    t.integer  "retype",     default: 0
  end

  create_table "identities", force: true do |t|
    t.integer  "user_id"
    t.string   "provider"
    t.string   "uid"
    t.string   "token"
    t.string   "secret"
    t.string   "username"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "identities", ["user_id"], name: "index_identities_on_user_id"

  create_table "industries", force: true do |t|
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "industry_recommendations", force: true do |t|
    t.integer  "subindustry_id"
    t.string   "name"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "numeric_id",        limit: 8
    t.string   "handle"
    t.string   "location"
    t.integer  "follower_count"
    t.integer  "following_count"
    t.integer  "tweet_count"
    t.integer  "favorites_count"
    t.integer  "listed_count"
    t.decimal  "score"
    t.string   "profile_image_url"
    t.string   "source_id"
    t.string   "email"
    t.boolean  "opted_out"
  end

  add_index "industry_recommendations", ["subindustry_id"], name: "index_industry_recommendations_on_subindustry_id"

  create_table "media", force: true do |t|
    t.string   "file_name"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "personalities", force: true do |t|
    t.integer  "brand_id"
    t.integer  "authentication_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "slug"
  end

  create_table "release_tweets", force: true do |t|
    t.integer  "release_id"
    t.string   "tweet_id"
    t.string   "to"
    t.string   "from"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "release_tweets", ["release_id"], name: "index_release_tweets_on_release_id"

  create_table "releases", force: true do |t|
    t.string   "name"
    t.datetime "start_date"
    t.datetime "end_date"
    t.integer  "creator_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.text     "copy"
    t.string   "url"
    t.integer  "status"
    t.boolean  "isTemplate",     default: false
    t.string   "headline",       default: ""
    t.integer  "brand_id"
    t.string   "slug"
    t.integer  "retype"
    t.integer  "industry_id"
    t.integer  "subindustry_id"
    t.string   "assets"
    t.integer  "logo_id"
    t.string   "time_zone"
    t.text     "subheading"
    t.string   "short_url"
    t.boolean  "has_tweeted",    default: false
    t.boolean  "published",      default: false
  end

  add_index "releases", ["brand_id"], name: "index_releases_on_brand_id"
  add_index "releases", ["creator_id"], name: "index_releases_on_creator_id"
  add_index "releases", ["industry_id"], name: "index_releases_on_industry_id"
  add_index "releases", ["logo_id"], name: "index_releases_on_logo_id"
  add_index "releases", ["subindustry_id"], name: "index_releases_on_subindustry_id"

  create_table "rich_rich_files", force: true do |t|
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "rich_file_file_name"
    t.string   "rich_file_content_type"
    t.integer  "rich_file_file_size"
    t.datetime "rich_file_updated_at"
    t.string   "owner_type"
    t.integer  "owner_id"
    t.text     "uri_cache"
    t.string   "simplified_type",        default: "file"
  end

  create_table "subindustries", force: true do |t|
    t.string   "name"
    t.integer  "industry_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "seed_id"
  end

  create_table "subscriptions", force: true do |t|
    t.string   "name"
    t.string   "price"
    t.integer  "admins"
    t.integer  "delegates"
    t.integer  "audiences"
    t.integer  "active_releases"
    t.integer  "agencies"
    t.integer  "brands"
    t.integer  "social_accounts"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "level"
  end

  create_table "taggings", force: true do |t|
    t.integer  "tag_id"
    t.integer  "taggable_id"
    t.string   "taggable_type"
    t.integer  "tagger_id"
    t.string   "tagger_type"
    t.string   "context",       limit: 128
    t.datetime "created_at"
  end

  add_index "taggings", ["tag_id", "taggable_id", "taggable_type", "context", "tagger_id", "tagger_type"], name: "taggings_idx", unique: true

  create_table "tags", force: true do |t|
    t.string  "name"
    t.integer "taggings_count", default: 0
  end

  add_index "tags", ["name"], name: "index_tags_on_name", unique: true

  create_table "users", force: true do |t|
    t.string   "email",                  default: "", null: false
    t.string   "encrypted_password",     default: "", null: false
    t.string   "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.integer  "sign_in_count",          default: 0,  null: false
    t.datetime "current_sign_in_at"
    t.datetime "last_sign_in_at"
    t.string   "current_sign_in_ip"
    t.string   "last_sign_in_ip"
    t.string   "confirmation_token"
    t.datetime "confirmed_at"
    t.datetime "confirmation_sent_at"
    t.string   "unconfirmed_email"
    t.integer  "failed_attempts",        default: 0,  null: false
    t.string   "unlock_token"
    t.datetime "locked_at"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "name"
    t.integer  "role"
    t.string   "slug"
    t.string   "family_name"
    t.string   "title"
    t.string   "organization"
    t.text     "hopes"
    t.string   "authentication_token"
    t.integer  "brand_id"
    t.string   "stripe_customer_id"
    t.string   "stripe_subscription_id"
    t.integer  "subscription_id"
    t.string   "time_zone"
    t.integer  "state"
    t.string   "code"
  end

  add_index "users", ["authentication_token"], name: "index_users_on_authentication_token", unique: true
  add_index "users", ["brand_id"], name: "index_users_on_brand_id"
  add_index "users", ["confirmation_token"], name: "index_users_on_confirmation_token", unique: true
  add_index "users", ["email"], name: "index_users_on_email", unique: true
  add_index "users", ["reset_password_token"], name: "index_users_on_reset_password_token", unique: true
  add_index "users", ["subscription_id"], name: "index_subscription_id"
  add_index "users", ["unlock_token"], name: "index_users_on_unlock_token", unique: true

end
