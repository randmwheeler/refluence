# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)
user = CreateAdminService.new.call
puts "CREATED ADMIN USER: " << user.email
user = CreateAdminService.new.call_again
puts "CREATED SECOND ADMIN USER: " << user.email
subs = CreateSubscriptionsService.new.call
puts "CREATED #{subs} SUBSCRIPTIONS"
system('rake load:industries[data/industries.json]')
system('rake load:seeds[data/seeds.2014-08-06.json]')