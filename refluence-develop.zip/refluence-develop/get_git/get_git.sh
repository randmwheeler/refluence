#!/bin/sh

cp get_git/excludes/excludes.global ~/.config/git/excludes
cp get_git/excludes/excludes.local .git/excludes

sudo cp get_git/configs/config.system /etc/gitconfig
cp get_git/configs/config.global ~/.config/git/config
cp get_git/configs/config.local .git/config
