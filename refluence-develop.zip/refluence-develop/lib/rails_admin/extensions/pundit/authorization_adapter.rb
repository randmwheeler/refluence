module RailsAdmin
  module Extensions
    module Pundit
      class AuthorizationAdapter
        def initialize(controller)
          @controller = controller
        end

        def policy(record)
          if record
            @controller.policy(record)
          else
            ::RailsAdminPolicy.new(@controller.current_user)
          end
        end
        private :policy

        def authorize(action, abstract_model = nil, model_object = nil)
          record = model_object || abstract_model && abstract_model.model
          unless policy(record).rails_admin?(action)
            raise ::Pundit::NotAuthorizedError, "not allowed to #{action} this #{record}"
          end
        end

        def authorized?(action, abstract_model = nil, model_object = nil)
          record = model_object || abstract_model && abstract_model.model
          policy(record).rails_admin?(action)
        end

        def query(action, abstract_model)
          @controller.policy_scope(abstract_model.model.scoped)
        end
      end
    end
  end
end
