include ApplicationHelper

def sign_in(user)
	visit new_user_session_path
	find("input[placeholder='Email Address']").set user.email
	find("input[placeholder='Password']").set user.password
	click_button "LOGIN"
	#cookies[:remember_token] = user.remember_token
end
