require 'spec_helper'

describe Agency do
	let(:agency) { create(:agency)}

	describe "basic information" do
		it ".all returns a list of agencies" do
			agency.save
			expect(Agency.all.count).not_to eq 0
		end

		it "should create a new instance given valid attributes" do 
			expect(agency).to be_valid
		end
	end

	describe "name" do 
		it "should respond to a name" do 
			expect(agency).to respond_to(:name)
		end

		it "should not allow a blank name" do 
			agency.name = ""
			expect(agency).not_to be_valid
		end

		it "should not allow a null name" do 
			agency.name = nil
			expect(agency).not_to be_valid
		end
	end


	describe "slug" do 

		it "should have a slug attribute" do 
			expect(agency).to respond_to(:slug)
		end

		it "should change when name changes" do 
			agency.save
			current_slug = agency.slug
			agency.name = agency.name + "y"
			agency.save 
			next_slug = agency.slug
			expect(current_slug).not_to eq next_slug
		end

		it "shouldn't be the same for same name" do 
			agency.save
			other = build(:agency)
			other.name = agency.name
			other.save
			expect(agency.slug).not_to eq other.slug
		end
	end

	describe "user" do 
		it "should respond to a user" do 
			expect(agency).to respond_to(:user)
		end

		it "should not allow for no user" do 
			agency.user = nil
			expect(agency).not_to be_valid
		end

		# Can't do this test because it will break everything
		#it "should not allow for user to have more than one agency" do 
		#	agency.save
		#	new_agency = create(:agency)
		#	new_agency.user = agency.user
		#	expect(new_agency).not_to be_valid
		#end
	end

	describe "brands" do 
		it "should respond to brands" do 
			expect(agency).to respond_to(:brands)
		end
	end
end
