require 'spec_helper'

describe Industry do
	let(:industry) { create(:industry)}

	describe "basic information" do
		it ".all returns a list of agencies" do
			industry.save
			expect(Industry.all.count).not_to eq 0
		end

		it "should create a new instance given valid attributes" do 
			expect(industry).to be_valid
		end
	end

	describe "name" do 
		it "should respond to a name" do 
			expect(industry).to respond_to(:name)
		end

		it "should not allow a blank name" do 
			industry.name = ""
			expect(industry).not_to be_valid
		end

		it "should not allow a null name" do 
			industry.name = nil
			expect(industry).not_to be_valid
		end

		it "should be equal to capitalize all" do
			updated_name = Utility.cap(industry.name)
			industry.save
			expect(industry.name).to eq updated_name
		end
	end
end
