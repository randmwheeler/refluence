require 'spec_helper'

describe Brand do
	let(:brand) { create(:brand)}

	describe "basic information" do
		it ".all returns a list of brands" do
			brand.save
			expect(Brand.all.count).not_to eq 0
		end

		it "should create a new instance given valid attributes" do 
			expect(brand).to be_valid
		end
	end

	describe "name" do 
		it "should respond to a name" do 
			expect(brand).to respond_to(:name)
		end

		it "should not allow a blank name" do 
			brand.name = ""
			expect(brand).not_to be_valid
		end

		it "should not allow a null name" do 
			brand.name = nil
			expect(brand).not_to be_valid
		end
	end

	describe "slug" do 

		it "should have a slug attribute" do 
			expect(brand).to respond_to(:slug)
		end

#		it "should change when name changes" do 
#			brand.save
#			current_slug = brand.slug
#			brand.name = brand.name + "y"
#			brand.save 
#			next_slug = brand.slug
#			expect(current_slug).not_to eq next_slug
#		end

		it "shouldn't be the same for same name" do 
			brand.save
			other = build(:brand)
			other.name = brand.name
			other.save
			expect(brand.slug).not_to eq other.slug
		end
	end

	describe "agency" do 
		it "should respond to an agency" do 
			expect(brand).to respond_to(:agency)
		end

		it "should not allow a null agency" do 
			brand.agency = nil
			expect(brand).not_to be_valid
		end

		it "should allow multiple brands for the same agency" do 
			brand.save
			new_brand = create(:brand)
			new_brand.agency = brand.agency
			expect(new_brand).to be_valid
		end
	end

	describe "releases" do 
		it "should respond to releases" do 
			expect(brand).to respond_to(:releases)
		end

	end
end
