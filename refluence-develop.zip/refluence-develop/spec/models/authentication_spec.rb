require 'spec_helper'

describe Authentication do
	let(:authentication) { create(:authentication)}

	describe "basic information" do
		it ".all returns a list of authentications" do
			authentication.save
			expect(Authentication.all.count).not_to eq 0
		end

		it "should create a new instance given valid attributes" do 
			expect(authentication).to be_valid
		end
	end
end
