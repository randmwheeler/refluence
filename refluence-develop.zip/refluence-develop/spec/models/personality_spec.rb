require 'spec_helper'

describe Personality do
	let(:personality) { create(:personality)}

	describe "basic information" do
		it ".all returns a list of personalities" do
			personality.save
			expect(Personality.all.count).not_to eq 0
		end

		it "should create a new instance given valid attributes" do 
			expect(personality).to be_valid
		end
	end
end
