require 'spec_helper'

describe Audience do
	let(:audience) { create(:audience)}

	describe "basic information" do
		it ".all returns a list of audiences" do
			audience.save
			expect(Audience.all.count).not_to eq 0
		end

		it "should create a new instance given valid attributes" do 
			expect(audience).to be_valid
		end
	end
end
