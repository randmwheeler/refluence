require 'spec_helper'

describe Subindustry do
	let(:subindustry) { create(:subindustry)}

	describe "basic information" do
		it ".all returns a list of agencies" do
			subindustry.save
			expect(Subindustry.all.count).not_to eq 0
		end

		it "should create a new instance given valid attributes" do 
			expect(subindustry).to be_valid
		end
	end

	describe "name" do 
		it "should respond to a name" do 
			expect(subindustry).to respond_to(:name)
		end

		it "should not allow a blank name" do 
			subindustry.name = ""
			expect(subindustry).not_to be_valid
		end

		it "should not allow a null name" do 
			subindustry.name = nil
			expect(subindustry).not_to be_valid
		end

		it "should be equal to capitalize all" do
			updated_name = Utility.cap(subindustry.name)
			subindustry.save
			expect(subindustry.name).to eq updated_name
		end
	end

	describe "industry" do 
		it "should respond to an industry" do
			expect(subindustry).to respond_to(:industry)
		end

		it "should not allow nil industry" do 
			subindustry.industry = nil
			expect(subindustry).not_to be_valid
		end
	end
end
