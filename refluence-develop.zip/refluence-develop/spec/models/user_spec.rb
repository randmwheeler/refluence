require 'spec_helper'

describe User do

	let(:beta){create(:beta_account)}
	let(:user){build(:user, email: beta.email, code: beta.code)}
	let(:attributes){attributes_for(:user)}

	it ".all returns a list of users" do
		user.save
		expect(User.all.count).not_to eq 0
	end

	it "should create a new instance given a valid attribute" do
		expect(user).to be_valid
	end

	describe "full name" do

		it "should have a name attribute" do
			expect(user).to respond_to(:name)
		end

		it "should require a name (first name)" do
			user.name = ""
			expect(user).not_to be_valid
		end

		it "should have a family name attribute" do
			expect(user).to respond_to(:family_name)
		end

		it "should not allow family name to be blank" do
			user.family_name = ""
			expect(user).not_to be_valid
		end
	end

	describe "slug" do

		it "should have a slug attribute" do
			expect(user).to respond_to(:slug)
		end

		it "should change when first name changes" do
			user.save
			current_slug = user.slug
			user.name = user.name + "y"
			user.save
			next_slug = user.slug
			expect(current_slug).not_to eq next_slug
		end

		it "should change when last name changes" do
			user.save
			current_slug = user.slug
			user.family_name = user.family_name + "son"
			user.save
			next_slug = user.slug
			expect(current_slug).not_to eq next_slug
		end

		it "shouldn't be the same for people with the same name" do
			user.save
			other_user = build(:user)
			other_user.name = user.name
			other_user.family_name = user.family_name
			other_user.save
			expect(user.slug).not_to eq other_user.slug
		end

	end

	describe "title" do

		it "should have a title attribute" do
			expect(user).to respond_to(:title)
		end

		it "should require a title" do
			user.title = ""
			expect(user).not_to be_valid
		end
	end

	describe "organization" do

		it "should have an organization attribute" do
			expect(user).to respond_to(:organization)
		end

		it "should require an organization" do
			user.organization = ""
			expect(user).not_to be_valid
		end

		it "should have an agency after saved" do
			user.save
			agency = user.agencies.first
			expect(agency).not_to eq nil
		end

		it "agency should have have same name as organization" do
			user.save
			user.organization = "Poop Nuggets"
			user.save
			expect(user.agencies.first.name).to eq user.organization
		end
	end

	describe "email" do

		it "should require an email address" do
			user.email = ""
			expect(user).not_to be_valid
		end

		it "should accept valid email addresses" do
			addresses = %w[user@foo.com THE_USER@foo.bar.org first.last@foo.jp]
			addresses.each do |address|
				new_beta = create(:beta_account, email: address)
				valid_email_user = build(:user, email: address, code: new_beta.code)
				expect(valid_email_user).to be_valid
			end
		end

		it "should reject invalid email addresses" do
			addresses = %w[user@foo,com user_at_foo.org example.user@foo.]
			addresses.each do |address|
				invalid_email_user = User.new(attributes.merge(:email => address))
				expect(invalid_email_user).not_to be_valid
			end
		end

		it "should reject duplicate email addresses" do
			user.save
			user_with_duplicate_email = build(:user)
			user_with_duplicate_email.email = user.email
			expect(user_with_duplicate_email).not_to be_valid
		end

		it "should reject email addresses identical up to case" do
			user.save
			user_with_duplicate_email = build(:user)
			user_with_duplicate_email.email = user.email.upcase
			expect(user_with_duplicate_email).not_to be_valid
		end
	end

	describe "passwords" do

		it "should have a password attribute" do
			expect(user).to respond_to(:password)
		end

		it "should have a password confirmation attribute" do
			expect(user).to respond_to(:password_confirmation)
		end
	end

	describe "password validations" do

		it "should require a password" do
			user.password = ""
			user.password_confirmation = ""
			expect(user).not_to be_valid
		end

		it "should require a matching password confirmation" do
			user.password_confirmation = "invalid"
			expect(user).not_to be_valid
		end

		it "should reject short passwords" do
			short = "a" * 5
			user.email = short
			expect(user).not_to be_valid
		end

		it "should reject long passwords" do
			long = "a" * 130
			user.email = long
			expect(user).not_to be_valid
		end
	end

	describe "password encryption" do

		it "should have an encrypted password attribute" do
			expect(user).to respond_to(:encrypted_password)
		end

		it "should set the encrypted password attribute" do
			expect(user.encrypted_password).not_to be_blank
		end

	end

	describe "hopes" do

		it "should have hopes attribute" do
			expect(user).to respond_to(:hopes)
		end

		it "should allow hopes to be optional" do
			user.hopes = ""
			expect(user).to be_valid
		end
	end

	describe "role" do
		it "should have a role" do
			expect(user).to respond_to(:role)
		end

		it "should have a default role of user when created" do
			user.save
			expect(user.role).to eq "user"
		end
	end

	describe "agencies" do
		it "should have an agency" do
			expect(user).to respond_to(:agencies)
		end

		describe "brands" do
			it "should respond to brands" do
				expect(user).to respond_to(:brands)
			end
		end
	end
end
