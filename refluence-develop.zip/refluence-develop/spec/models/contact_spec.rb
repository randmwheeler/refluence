require 'spec_helper'

describe Contact do
	let(:contact) { create(:contact)}

	describe "basic information" do
		it ".all returns a list of contacts" do
			contact.save
			expect(Contact.all.count).not_to eq 0
		end

		it "should create a new instance given valid attributes" do 
			expect(contact).to be_valid
		end
	end
end
