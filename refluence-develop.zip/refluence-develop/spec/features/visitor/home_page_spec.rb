require 'spec_helper'

# Feature: Home Page (Guest Visits Home Page use case)
#	As a visitor
#	I want to visit the home page
#	So I can learn more about the website, sign up, or sign in
feature 'Home Page: ' do

	# Scenario: Visit the Home Page (Task 1/2)
	#	Given I am a visitor
	#	When I visit the home page
	#	Then I should see "Welcome to Refluence"
	scenario 'Visit the Home Page' do
		visit root_path
		expect(page).to have_content 'Your Content in the Right Hands'
		expect(page).to have_link 'Sign up'
		expect(page).to have_link 'Login'
	end

	# Scenario: Click on Registration Link (Task 3)
	# 	Given I am a visitor
	# 	When I click on the Registration link
	# 	Then I should see Registration page
	scenario 'Click on Registration Link' do
		visit root_path
		click_link "Sign up"
		expect(page).to have_content "Lets create your refluence Account"
	end

	# Scenario: Click on Login Link (Task 4)
	# 	Given I am a visitor
	# 	When I click on the Login link
	# 	Then I should see the Login page
	scenario 'Click on Login Link' do
		visit root_path
		click_link "Login"
		@signin_text = "Log in"
		expect(page).to have_content @signin_text
	end
end
