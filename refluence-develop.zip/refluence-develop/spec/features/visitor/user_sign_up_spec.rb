require 'spec_helper'

# Feature: Sign up (Guess Signs up as New user use case)
#	As a visitor
#	I want to sign up
#	So I can get access to protected sections of the site
feature 'Sign up: ' do

	let(:sign_up_text){"SUBMIT"}
	let(:user){build(:user)}
	# ____________ VALID CONDITIONS ____________ #
	# Scenario: Visitor Signs up With Valid Data
	#	Given I am a visitor
	#	When I sign up with valid data
	#	Then I should see a confirmation message
	scenario 'User Signs Up With Valid Data' do
		visit new_user_registration_path
			find("input[placeholder='First Name']").set user.name
			find("input[placeholder='Last Name']").set user.family_name
			find("input[placeholder='Title']").set user.title
			find("input[placeholder='Organization']").set user.organization
			find("input[placeholder='Email Address']").set user.email
			find("input[placeholder='Confirm Email Address']").set user.email
			find("input[placeholder='Password']").set user.password
			find("input[placeholder='Confirm Password']").set user.password
			find("#tos").set true
		click_button sign_up_text
		expect(page).to have_content "Your Content in the Right Hands"
	end

	# ____________ INVALID CONDITIONS __________ #
	# Scenario: Vistor Signs up With no first name
	# 	Given I am a visitor
	# 	When I sign up with no first name
	# 	Then I should see an error message
	scenario "User Signs Up With No first name", js: true do
		visit new_user_registration_path
			find("input[placeholder='Title']").set user.title
			find("input[placeholder='Organization']").set user.organization
			find("input[placeholder='Email Address']").set user.email
			find("input[placeholder='Confirm Email Address']").set user.email
			find("input[placeholder='Password']").set user.password
			find("input[placeholder='Confirm Password']").set user.password
		click_button sign_up_text
		expect(page).to have_content "can't be blank"
	end

	# Scenario: Vistor Signs up With no title
	# 	Given I am a visitor
	# 	When I sign up with no title
	# 	Then I should see an error message
	scenario "User Signs Up With No title", js: true do
		visit new_user_registration_path
			find("input[placeholder='First Name']").set user.name
			find("input[placeholder='Organization']").set user.organization
			find("input[placeholder='Email Address']").set user.email
			find("input[placeholder='Confirm Email Address']").set user.email
			find("input[placeholder='Password']").set user.password
			find("input[placeholder='Confirm Password']").set user.password
			find("#tos").set true
		click_button sign_up_text
		expect(page).to have_content "can't be blank"
	end

	# Scenario: Vistor Signs up With no organization
	# 	Given I am a visitor
	# 	When I sign up with no organization
	# 	Then I should see an error message
	scenario "User Signs Up With No organization", js: true do
		visit new_user_registration_path
			find("input[placeholder='First Name']").set user.name
			find("input[placeholder='Title']").set user.title
			find("input[placeholder='Email Address']").set user.email
			find("input[placeholder='Confirm Email Address']").set user.email
			find("input[placeholder='Password']").set user.password
			find("input[placeholder='Confirm Password']").set user.password
		click_button sign_up_text
		expect(page).to have_content "can't be blank"
	end

	# Scenario: Vistor Signs up With no email
	# 	Given I am a visitor
	# 	When I sign up with no email
	# 	Then I should see an error message
	scenario "User Signs Up With No Email", js: true do
		visit new_user_registration_path
			find("input[placeholder='First Name']").set user.name
			find("input[placeholder='Title']").set user.title
			find("input[placeholder='Organization']").set user.organization
			find("input[placeholder='Password']").set user.password
			find("input[placeholder='Confirm Password']").set user.password
		click_button sign_up_text
		expect(page).to have_content "can't be blank"
	end

	# Scenario: Visitor Signs up With an Invalid Email
	# 	Given I am a visitor
	# 	When I sign up with an invalid email
	# 	Then I should see an error message that it's taken
	scenario "User Signs Up With Invalid Email", js: true do
		visit new_user_registration_path
			find("input[placeholder='First Name']").set user.name
			find("input[placeholder='Title']").set user.title
			find("input[placeholder='Organization']").set user.organization
			find("input[placeholder='Email Address']").set "poop"
			find("input[placeholder='Confirm Email Address']").set user.email
			find("input[placeholder='Password']").set user.password
			find("input[placeholder='Confirm Password']").set user.password
		click_button sign_up_text
		expect(page).to have_content "is not a valid email"
	end

	# Scenario: Visitor Signs up With an Mismatched Email
	# 	Given I am a visitor
	# 	When I sign up with an mismatched email
	# 	Then I should see an error message that it's taken
	scenario "User Signs Up With Mismatched Email", js: true do
		visit new_user_registration_path
			find("input[placeholder='First Name']").set user.name
			find("input[placeholder='Title']").set user.title
			find("input[placeholder='Organization']").set user.organization
			find("input[placeholder='Email Address']").set user.email
			find("input[placeholder='Confirm Email Address']").set "poop"
			find("input[placeholder='Password']").set user.password
			find("input[placeholder='Confirm Password']").set user.password
		click_button sign_up_text
		expect(page).to have_content "Something's wrong"
	end

	# Scenario: Visitor Signs up With an Existing Email
	# 	Given I am a visitor
	# 	When I sign up with an existing email
	# 	Then I should see an error message that it's taken
	scenario "User Signs Up With Existing Email" do
		@user = create(:user)
		visit new_user_registration_path
			find("input[placeholder='First Name']").set user.name
			find("input[placeholder='Title']").set user.title
			find("input[placeholder='Organization']").set user.organization
			find("input[placeholder='Email Address']").set @user.email
			find("input[placeholder='Confirm Email Address']").set @user.email
			find("input[placeholder='Password']").set user.password
			find("input[placeholder='Confirm Password']").set user.password
		click_button sign_up_text
		expect(page).to have_content "has already been taken"
	end

	# Scenario: Vistor Signs up With no password
	# 	Given I am a visitor
	# 	When I sign up with no password
	# 	Then I should see an error message
	scenario "User Signs Up With No Password", js: true do
		visit new_user_registration_path
			find("input[placeholder='First Name']").set user.name
			find("input[placeholder='Title']").set user.title
			find("input[placeholder='Organization']").set user.organization
			find("input[placeholder='Email Address']").set user.email
			find("input[placeholder='Confirm Email Address']").set user.email
			find("input[placeholder='Password']").set ""
		click_button sign_up_text
		expect(page).to have_content "can't be blank"
	end

	# Scenario: Vistor Signs up With short password
	# 	Given I am a visitor
	# 	When I sign up with short password
	# 	Then I should see an error message
	scenario "User Signs Up With Short Password", js: true do
		visit new_user_registration_path
			@min = 8
			@pass = "a" * (@min - 1)
			find("input[placeholder='First Name']").set user.name
			find("input[placeholder='Title']").set user.title
			find("input[placeholder='Organization']").set user.organization
			find("input[placeholder='Email Address']").set user.email
			find("input[placeholder='Confirm Email Address']").set user.email
			find("input[placeholder='Password']").set @pass
			find("input[placeholder='Confirm Password']").set @pass
		click_button sign_up_text
		expect(page).to have_content "is too short"
	end

	# Scenario: Vistor Signs up With long password
	# 	Given I am a visitor
	# 	When I sign up with long password
	# 	Then I should see an error message
	scenario "User Signs Up With Long Password", js: true do
		visit new_user_registration_path
			@max = 128
			@pass = "a" * (@max+1)
			find("input[placeholder='First Name']").set user.name
			find("input[placeholder='Title']").set user.title
			find("input[placeholder='Organization']").set user.organization
			find("input[placeholder='Email Address']").set user.email
			find("input[placeholder='Confirm Email Address']").set user.email
			find("input[placeholder='Password']").set @pass
			find("input[placeholder='Confirm Password']").set @pass
		click_button sign_up_text
		expect(page).to have_content "is too long"
	end

	# Scenario: Vistor Signs up With passwords that don't match
	# 	Given I am a visitor
	# 	When I sign up with mismatched password
	# 	Then I should see an error message
	scenario "User Signs Up With Mismatched Password", js: true do
		visit new_user_registration_path
			find("input[placeholder='First Name']").set user.name
			find("input[placeholder='Title']").set user.title
			find("input[placeholder='Organization']").set user.organization
			find("input[placeholder='Email Address']").set user.email
			find("input[placeholder='Confirm Email Address']").set user.email
			find("input[placeholder='Password']").set user.password
			find("input[placeholder='Confirm Password']").set "poop"
		click_button sign_up_text
		expect(page).to have_content "Something's wrong"
	end
end
