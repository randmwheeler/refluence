require 'spec_helper'

# Feature: Access Restrictions
# 	As a user
# 	I want to be approved/denied access based on my role
# 	I also want the system to protect against bruteforce
feature 'Access Restriction: ' do

	let(:login_text){"LOGIN"}
	# Scenario: Admin Signs In to Access Admin Panel
	# 	Given I am an admin user
	# 	When I log in and access the admin panel
	# 	Then I should be able to view it
	scenario "Admin Signs In And Accesses Admin Panel" do
		@user = create(:confirmed_admin)
		@user.admin!
		visit new_user_session_path
			find("input[placeholder='Email Address']").set @user.email
			find("input[placeholder='Password']").set @user.password
		click_button login_text
		visit "/admin"
		expect(page).to have_content "Admin"
	end

	# Scenario: User Signs In to Access Admin Panel
	# 	Given I am an user
	# 	When I log in and access the admin panel
	# 	Then I should be not able to view it
	scenario "User Signs In And Accesses Admin Panel" do
		@user = create(:confirmed_user)
		visit new_user_session_path
			find("input[placeholder='Email Address']").set @user.email
			find("input[placeholder='Password']").set @user.password
		click_button login_text
		visit "/admin"
		expect(page).to have_content "You are not authorized to access this page."
	end
end
