require 'spec_helper'

# Feature: Log in (User Logs In User Case)
# 	As a user
# 	I want to Log in
# 	So I can access protected sections of the site
feature 'Log in: ' do

	let(:login_text){"LOGIN"}

	# ____________ VALID CONDITIONS ____________ #
	# Scenario: User Visits Login Page
	# 	Given I am a user
	# 	When I visit the Login page
	# 	Then I should see Log in text
	scenario 'User Visits Log in Page' do
		visit new_user_session_path
		@signin_text = "Log in"
		expect(page).to have_content @signin_text
	end

	# Scenario: User Signs in with Valid Data
	# 	Given I am an confirmed user
	# 	When I Log in with valid data
	# 	Then I should see a welcome message
	scenario 'Confirmed User Signs In With Valid Data' do
		visit new_user_session_path
			@user = create(:confirmed_user)
			find("input[placeholder='Email Address']").set @user.email
			find("input[placeholder='Password']").set @user.password
		click_button login_text
		expect(page).to have_content "Which plan suits your need best?"
	end

	# Scenario: Unconfirmed User Signs in with Valid Data
	# 	Given I am an unconfirmed user
	# 	When I Log in with valid data
	# 	Then I should see a please confirm message
	scenario 'Unconfirmed User Signs In With Valid Data' do
		visit new_user_session_path
			@user = create(:user)
			find("input[placeholder='Email Address']").set @user.email
			find("input[placeholder='Password']").set @user.password
		click_button login_text
		expect(page).to have_content "You have to confirm your account before continuing."
	end

	# ____________ INVALID CONDITIONS __________ #
	# Scenario: User Signs in with no password
	# 	Given I am an existing user
	# 	When I Log in with no password
	# 	Then I should see an error message
	scenario 'User Signs In with No Password' do
		visit new_user_session_path
			@user = create(:confirmed_user)
			find("input[placeholder='Email Address']").set @user.email
		click_button login_text
		expect(page).to have_content "Invalid email or password"
	end

	# Scenario: User Signs in with wrong password
	# 	Given I am an existing user
	# 	When I Log in with wrong password
	# 	Then I should see an error message
	scenario 'User Signs In with Invalid Password' do
		visit new_user_session_path
			@user = create(:confirmed_user)
			find("input[placeholder='Email Address']").set @user.email
			find("input[placeholder='Password']").set "THISISNTWRITE"
		click_button login_text
		expect(page).to have_content "Invalid email or password"
	end

	# Scenario: User Signs in with wrong email
	# 	Given I am an existing user
	# 	When I Log in with wrong email
	# 	Then I should see an error message
	scenario 'User Signs In with Invalid Email' do
		visit new_user_session_path
			@user = create(:confirmed_user)
			find("input[placeholder='Email Address']").set "#{@user.email}blah"
			find("input[placeholder='Password']").set @user.password
		click_button login_text
		expect(page).to have_content "Invalid email or password"
	end

	# Scenario: User Signs in with no email
	# 	Given I am an existing user
	# 	When I Log in with no email
	# 	Then I should see an error message
	scenario 'User Signs In with No Email' do
		visit new_user_session_path
			@user = create(:confirmed_user)
			find("input[placeholder='Email Address']").set ""
			find("input[placeholder='Password']").set @user.password
		click_button login_text
		expect(page).to have_content "Invalid email or password"
	end

	# Scenario: User Fails to Log in Multiple Times
	# 	Given I am a user
	# 	When I fail Log in 3 times
	# 	Then I should be locked out of my account
	scenario 'User Signs In With Invalid Data Multipe Times' do
		@user = create(:user)
		visit new_user_session_path
		0.upto 2 do
			find("input[placeholder='Email Address']").set @user.email
			find("input[placeholder='Password']").set "invalid"
			click_button login_text
		end
		expect(page).to have_content "Your account is locked."
	end
end
