require 'spec_helper'


# Feature: Release Creation
# 	As a user
# 	I want to create a Release
# 	So I the system can help me reach more people
feature 'Release Creation: ' do

	before(:each) {
		@user = build(:confirmed_user)
		@agency = build(:agency)
		@agency.user = @user
		@agency.save
		@brand = build(:brand)
		@brand.agency = @agency
		@brand.save
		sign_in @user }
	# Scenario: Signed In User Creates a new Release with Valid Data
	# 	Given I am a signed in user
	# 	When I create a new release with valid data
	# 	Then I should see a success message
	scenario "Signed In User Creates a New Release with Default Data" do
		visit brand_releases_path(@brand.id)
		click_button "New Release"
		click_button "CREATE NEW"
		expect(page).to have_content "success"
	end
end
