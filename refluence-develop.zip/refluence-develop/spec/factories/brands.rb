# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :brand do
    name {Faker::Lorem.word}
    agency
  end
end
