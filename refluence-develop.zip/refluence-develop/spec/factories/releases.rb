# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :release do
    name { Faker::Lorem.sentence}
    start_date Time.now
    end_date nil
    creator {build(:confirmed_user)}
    brand 
    copy ""
    url "http://www.google.com"
    industry
    subindustry 
    retype {Release.retypes.first[0]}
  end
end
