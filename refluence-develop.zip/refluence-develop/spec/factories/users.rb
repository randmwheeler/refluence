FactoryGirl.define do
	factory :user do
		email {Faker::Internet.email}
		password {Faker::Internet.password(8)}
		name {Faker::Name.first_name}
		family_name {Faker::Name.last_name}
		title {Faker::Name.title}
		organization {Faker::Company.name}
		hopes {Faker::Lorem.paragraph(3)}
		code ""

		factory :confirmed_user do
			confirmed_at Time.now

			factory :confirmed_admin do
				after(:create) {|user| user.admin!}
			end
		end
	end
end
