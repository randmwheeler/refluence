# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :subindustry do
    name {Faker::Commerce.product_name}
    industry 
  end
end
