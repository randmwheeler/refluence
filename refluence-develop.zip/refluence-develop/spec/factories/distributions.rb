# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :distribution do
    release nil
    start_date "2014-08-01 02:38:22"
    end_date "2014-08-01 02:38:22"
    time_zone "MyString"
  end
end
