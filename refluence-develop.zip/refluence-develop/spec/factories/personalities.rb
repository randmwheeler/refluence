# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :personality do
    brand {build(:brand)}
	authentication {build(:authentication)}
  end
end
