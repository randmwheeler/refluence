# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :contact do
    name {Faker::Name.name}
    phone "(206) 266-7180"
    fax "(206) 266-7180"
    email {Faker::Internet.email}
  end
end
