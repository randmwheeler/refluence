# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :audience do
    name {Faker::Lorem.word}
    reach 1
    relevance 1
    renown 1
    neighborhoods "MyString"
  end
end
