# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :release_tweet do
    release nil
    tweet_id "MyString"
    to "MyString"
    from "MyString"
  end
end
