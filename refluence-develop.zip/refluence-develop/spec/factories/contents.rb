# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :content do
    retype 1
    headline "MyString"
    copy "MyText"
    assets "MyString"
    release ""
  end
end
