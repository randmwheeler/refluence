# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :subscription do
    price "MyString"
    users 1
    audiences 1
    active_releases 1
    agencies 1
    brands 1
    social_accounts 1
  end
end
