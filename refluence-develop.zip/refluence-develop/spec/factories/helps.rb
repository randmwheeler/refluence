# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :help do
    name "MyString"
    content "MyText"
    page "MyString"
  end
end
