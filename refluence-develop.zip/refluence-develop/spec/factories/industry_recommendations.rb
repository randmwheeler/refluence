# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :industry_recommendation, :class => 'IndustryRecommendations' do
    subindustry nil
    name "MyString"
  end
end
