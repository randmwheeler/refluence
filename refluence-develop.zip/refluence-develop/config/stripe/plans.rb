# This file contains descriptions of all your stripe plans

# Example
# Stripe::Plans::PRIMO #=> 'primo'

# Stripe.plan :primo do |plan|
#
#   # plan name as it will appear on credit card statements
#   plan.name = 'Acme as a service PRIMO'
#
#   # amount in cents. This is 6.99
#   plan.amount = 699
#
#   # interval must be either 'week', 'month' or 'year'
#   plan.interval = 'month'
#
#   # only bill once every three months (default 1)
#   plan.interval_count = 3
#
#   # number of days before charging customer's card (default 0)
#   plan.trial_period_days = 30
# end

# Once you have your plans defined, you can run
#
#   rake stripe:prepare
#
# This will export any new plans to stripe.com so that you can
# begin using them in your API calls.

Stripe.plan :small do |plan|
  plan.name = 'Small Plan'
  #plan.amount = 49900 # $499.00
  plan.amount = 20000 # $200.00
  plan.interval = 'month'
end

Stripe.plan :medium do |plan|
  plan.name = 'Medium Plan'
  #plan.amount = 99900 # $999.00
  plan.amount = 40000 # $400.00
  plan.interval = 'month'
end

Stripe.plan :large do |plan|
  plan.name = 'Large Plan'
  #plan.amount = 199900 # $1999.00
  plan.amount = 60000 # $600.00
  plan.interval = 'month'
end

Stripe.plan :small_year do |plan|
  plan.name = 'Small Plan (Yearly Subscription)'
  #plan.amount = 538920 # $5389.20 (10% off)
  plan.amount = 216000 # $2160.00 (10% off)
  plan.interval = 'year'
end

Stripe.plan :medium_year do |plan|
  plan.name = 'Medium Plan (Yearly Subscription)'
  #plan.amount = 1078920 # $10789.20 (10% off)
  plan.amount = 432000 # $4320.00 (10% off)
  plan.interval = 'year'
end

Stripe.plan :large_year do |plan|
  plan.name = 'Large Plan (Yearly Subscription)'
  #plan.amount = 2158920 # $21589.20 (10% off)
  plan.amount = 648000 # $6480.00 (10% off)
  plan.interval = 'year'
end