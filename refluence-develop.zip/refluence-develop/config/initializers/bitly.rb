Bitly.configure do |config|
  config.api_version = 3
  config.login = Rails.application.secrets.test_bitly_username
  config.api_key = Rails.application.secrets.test_bitly_generic_access_token
end