# Create S3 sandboxes

# S3 assets sandbox available as global variable $assetsBox
#CreateS3AssetsSandboxService.new.call

# S3 campaigns sandbox available as global variable $campaignsBox
#CreateS3CampaignsSandboxService.new.call