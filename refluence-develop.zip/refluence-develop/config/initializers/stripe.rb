# Stripe API keys
Rails.application.config.stripe.publishable_key = Rails.application.secrets.stripe_publishable_key
Rails.application.config.stripe.secret_key = Rails.application.secrets.stripe_secret_key