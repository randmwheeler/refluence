S3DirectUpload.config do |c|
  c.access_key_id     = Rails.application.secrets.amazon_s3_assets_bucket_key
  c.secret_access_key = Rails.application.secrets.amazon_s3_assets_bucket_secret
  c.bucket            = Rails.application.secrets.amazon_s3_assets_bucket_name
  c.region            = "s3"
  c.url               = "https://#{c.bucket}.s3.amazonaws.com"
end
