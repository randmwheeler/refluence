# config valid only for Capistrano 3.1
lock '3.4.0'

# set :stages, %w(production staging)
#  set :default_stage, 'staging'
# set :rvm_ruby_version: '2.1.2'
# set :rvm_autolibs_flag, 'read-only'


set :application, 'refluence'
set :scm, :git
set :repo_url, 'git@github.com:refluence/refluence.git'

# Default branch is :master
# ask :branch, proc { `git rev-parse --abbrev-ref HEAD`.chomp }.call
set :branch, :develop
#set :branch, ENV['branch'] if ENV['branch']

set :format, :pretty
set :log_level, :debug
set :pty, true

set :deploy_to, '/home/deploy/refluence'
set :linked_files, %w{config/database.yml config/secrets.yml}
set :linked_dirs, %w{bin log tmp/pids tmp/cache tmp/sockets vendor/bundle public/system}
set :keep_releases, 5

# Default value for default_env is {}
# set :default_env, { path: "/opt/ruby/bin:$PATH" }

#load 'deploy/assets'

namespace :deploy do

  desc 'Restart application'
  task :restart do
    on roles(:app), in: :sequence, wait: 5 do
      # Your restart mechanism here, for example:
      execute :touch, release_path.join('tmp/restart.txt')
    end
  end

  after :publishing, :restart

  after :restart, :clear_cache do
    on roles(:web), in: :groups, limit: 3, wait: 10 do
      # Here we can do anything such as:
      # within release_path do
      #   execute :rake, 'cache:clear'
      # end
    end
  end

  after :finishing, 'deploy:cleanup'
end

namespace :seed do
  desc "Run rake db:seed on remote server."
  task :default do
    run "cd #{deploy_to}/current; bundle exec rake db:seed RAILS_ENV=#{rails_env}"
  end
end

namespace :migrate do
  desc "Run rake db:migrate on remote server."
  task :default do
    run "cd #{deploy_to}/current; buncle exec rake db:migrate RAILS_ENV=#{rails_env}"
  end
end
