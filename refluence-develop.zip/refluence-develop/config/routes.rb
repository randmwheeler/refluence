Refluence::Application.routes.draw do
  resources :beta_accounts
  resources :agencies
  resources :agency_images
  resources :helps
  resources :brand_authentications
  resources :industry_recommendations
  resources :identities do
    collection do
      get "update"
    end
  end

  mount Rich::Engine => '/rich', :as => 'rich'
  resources :agencies
  resources :subscriptions
  resources :brands do
    get 'select', on: :collection
    post 'select', on: :collection
    resources :releases do 
      get 'view', on: :member
      get 'tweet', on: :member
    end
  	resources :audiences
  	resources :personalities
  end

  resources :media_contents, only: [:create]

  get "/choose-plan", to: "subscriptions#index", as: :select_subscription
  get "/select-dashboard", to: "brands#select", as: :select_dashboard
  get "/downgrade", to: "subscriptions#downgrade", as: :downgrade

  post '/optout', to: 'users#optout'

  # Static pages
  get 'pages/index'
  get 'pages/our_story'
  get 'pages/pricing'
  get 'pages/how_it_works'
  get 'pages/investor_information'
  get 'pages/help_and_support'
  get 'pages/faqs'
  get 'pages/our_team'
  get 'pages/contact'
  get 'pages/about'
  get 'pages/wiki'

  get 'pages/stats'

  # Notices
  get 'pages/copyright'
  get 'pages/privacy'
  get 'pages/terms'

  mount RailsAdmin::Engine => '/admin', as: 'rails_admin'

  root :to => "pages#index"

  devise_for :users, :controllers => {:registrations => "registrations", :omniauth_callbacks => 'omniauth_callbacks'}
  resources :users
  match '/users/:id/finish_signup' => 'users#finish_signup', via: [:get,:patch], as: :finish_signup
  devise_scope :user do
    get "/login" => "devise/sessions#new"
    get "/logout" => "devise/sessions#destroy"
    get "/recover-password" => "devise/passwords#new"
    get "/create-account" => "registrations#new"
  end
  get "*path" => redirect("/")
end
