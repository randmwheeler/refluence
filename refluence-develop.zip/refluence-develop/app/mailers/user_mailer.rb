class UserMailer < ActionMailer::Base
  default from: "info@refluence.com"

  def beta_email beta 
  	@beta = beta
  	@full_url = "http://" + Rails.application.secrets.domain_name.to_s
  	@url = Rails.application.secrets.domain_name.to_s
  	mail(to: @beta.email, subject: "Welcome to re:fluence, please enjoy your beta account")
  end
end
