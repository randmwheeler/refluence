// Function to validate the sign up form
function validate_sign_up_form(event){
	event.preventDefault();
	var error_div = $("#alerts");	// Where to send the error message
	var valid = true;				// Was it valid
	var required = ["#user_name", "#user_family_name", "#user_title", "#user_organization"];
	for(var i=0;i < required.length;i++){ // Check all the required field to make sure they exist
		if(!validate_presence_with_error(required[i])){
			valid = false;
		}
	}
	var current = "#user_email";	// Make sure the email exists and is valid
	if(!validate_email_with_error(current)){
		valid = false;
	}else{
		if(!validate_same(current)){// Make sure the confirmation is the same
			valid = false;
		}
	}
	current = "#user_password";		// Make sure the password exists and is valid
	if(!validate_password_with_error(current)){
		valid = false;
		if(!validate_same(current)){// Make sure the confirmation is the same
			valid = false;
		}
	}
	if(!$("#tos").prop("checked")){	// Make sure the user has accepts the tos
		valid = false
		$("#tos-alert").html("You must accept the terms and conditions");
		$("#tos-alert").addClass(alert_class);
	}else{							// If it was check redo the classes
		$("#tos-alert").html("");
		$("#tos-alert").removeClass(alert_class);
	}
	if(valid){						// It was valid 
		error_div.removeClass(alert_class);	// Remove alert class
		error_div.html(success_message);	// Add success message to alert
		$("#new_user").submit();			// Submit the form
	}else{
		error_div.html("Please fix the errors above:");// Otherwise display error messages
		error_div.addClass(alert_class);	// And add the error class
	}
	return false;
}

// Function to accept the tos and close the tos modal
function select_tos(){
	$("#tos").prop("checked",true);
	$("#tos-modal").modal("hide");
}

function add_error_divs(){
	$(":input").each(function(){
		var type = $(this).prop("type");
		if(type == "text" || type == "email" || type == "password"){
			var id = $(this).prop("id");
			var new_id = id + "-alert";
			var div = "<div id='" + new_id + "' class='dark-pattern no-pad signup-alert'></div>";
			$(this).after(div);
		}
	});
}

function sign_up_scripts(){
	if($("#sign-up").length){
		$("#alerts").addClass("signup-alert")
		$("#user_name").on("keyup blur change", function(){
			validate_presence_with_error("#user_name");
		});
		$("#user_family_name").on("keyup blur change", function(){
			validate_presence_with_error("#user_family_name");
		});
		$("#user_title").on("keyup blur change", function(){
			validate_presence_with_error("#user_title");
		});
		$("#user_organization").on("keyup blur change", function(){
			validate_presence_with_error("#user_organization");
		});
		set_validations("#user_email",true);
		set_validations("#user_password",false);
		$("#cancel-button").on("click",function(event){
			event.preventDefault();
			window.location = $("#cancel-link").prop("href");
		})
		$("#submit-button").on('click',function(event){
			validate_sign_up_form(event);
			$("#alerts").addClass("submit-signup") //Signup-alert class on all but submit
		});
		$("#accept-tos").on("click",select_tos);
		add_error_divs();
	}
}

$(document).ready(sign_up_scripts);
$(document).on('page:load', sign_up_scripts);
