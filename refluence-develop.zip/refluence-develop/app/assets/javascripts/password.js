/* SCRIPTS FOR PASSWORD RECOVERY PAGE */

// Make sure that both email is valid and the confirmation matches before submitting 
// Will display the errors found for the user below the login portion
function validate_pass_form(event){
	event.preventDefault();		// Prevent default action
	var error_div = $("#alerts");// Div to store the error
	var current = "#user_email"
	if(validate_email_with_error(current)){
		if(validate_same(current)){
			error_div.html(success_message);
			$("#new_user").submit(); // Submit the form
		}
	}
	return false;
}

// All scripts that need to run for the login page 
function password_scripts(){
	if($("#password").length){
		set_validations("#user_email",true);
		$("#send-button").on('click',function(event){
			validate_pass_form(event);
		});
		add_error_divs();
	}
}
			
$(document).ready(password_scripts);
$(document).on('page:load',password_scripts);
