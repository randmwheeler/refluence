//=require rich/base
