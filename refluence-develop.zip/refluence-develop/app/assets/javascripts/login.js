/* ALL SCRIPTS FOR LOGIN/BETA SIGN UP PAGE */

// Make sure that both username and password are valid before submitting
// Will display the errors found for the user below the login portion
function validate_login(event){
	event.preventDefault();		// Prevent default action
	var error = "Please review the problems above:";// Stores the error to display
	var email = $("#user_email").val();// Email that was entered
	var pass = $("#user_password").val();// Password that was entered
	var error_div = $("#login-alerts");// Div to store the error
	var valid = true;
	if(!validate_email_with_error("#user_email")){
		valid = false;
	}		
	else if(!validate_password_with_error("#user_password")){
		valid = false;
	}
	if(!valid){		// We have an error message
		error_div.html(error);// Set the error message
		error_div.addClass("alert-danger"); // Set the error class
		return false;		// Make sure we do nothing more
	}else{
		error_div.html(""); // Remove errors
		error_div.removeClass("alert-danger");// Remove error class
		$("#new_user").submit(); // Submit the form
	}
}

// Function to validate the request form on submit
// Will display errors if any occur else
//	It will display the success message
function validate_request(event){
	event.preventDefault();		// Prevent default action
	var error = "";				// Store any errors to display
	var name = $("#beta_account_name");// Name that was entered
	var email = $("#beta_account_email");// Email that was entered
	var error_div = $("#beta-alerts"); 	// Div to store error or success
	if(!validate_presence(name)){// Make sure they entered a name
		error = error + "Name can't be blank.</br>";
	}
	if(!validate_presence(email)){// Make sure they entered an email
		error = error + "Email can't be blank.</br>";
	}else{						// If it wasn't blank make sure it's valid
		if(!validate_email(email)){
			error = error + "Email is not in a valid format.</br>";
		}
	}							
	if(error != ""){			// We have an error message
		error_div.html(error);	// Set the error message
		error_div.addClass("alert-danger"); // Set the error class
		return false; 			// We done
	}else{						// We have success
		error_div.html(success_message); // Display success
		error_div.removeClass("alert-danger"); // Remove error class
		error_div.addClass("alert-success");// Add success class
		$("#new_beta_account").submit();  	// Still do nothing until we have somewhere to send it
	}
}

// All scripts that need to run for the login page 
function login_scripts(){
	if($("#login").length){	
		add_error_divs();
		$("#user_email").on('keyup blur change',function(){
			validate_email_with_error("#user_email");
		});
		$("#user_password").on('keyup blur change',function(){
			validate_password_with_error("#user_password");
		});
		$("#login-button").on('click',function(event){
			validate_login(event);
		});
		$("#request-button").on('click',function(event){
			validate_request(event);
		});
	}
}
			
$(document).ready(login_scripts);
$(document).on('page:load',login_scripts);
