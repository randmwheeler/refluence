function set_and_submit(){
	var id = $(this).prop("id")
	$("#user_subscription option").filter(function(){
		return this.text == id;
	}).attr('selected',true);
	$("#subscription-submit").click();
}

function subscription_scripts(){
	if($("#subscription").length){
		$(".sub").on("click",set_and_submit);
	}
	$("button.stripe-button-el").addClass("full-width btn btn-md btn-primary btn-block plan-padding sub");	//Add full width to stripe buttons on subscription page
	$("button.stripe-button-el").removeClass("stripe-button-el");	//Add full width to stripe buttons on subscription page
}

$(document).ready(subscription_scripts);
$(document).on('page:load', subscription_scripts);