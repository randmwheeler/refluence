/* VALIDATION FUNCTION SHARED BETWEEN PAGES *?


/* GENERAL VALIDATION FUNCTIONS */

// GLOBALS USED FOR PASSWORD LENGTH AND SUCCESS
var min = 8;	// Min password length
var max = 128;	// Max password length
var success_message = "Your request was successfully submitted.";
var valid_color = "green";
var invalid_color = "red";
var alert_class = "alert-danger";
var success_class = "alert-success";
var suc_message = "Looking good";

// Function to determine if a value is empty
function isEmpty(value){
	var length = value.length
	if(value == ""){
		return true;
	}else{
		return false;
	}
}

// Function to determine if a value is a valid email
// Does not guarantee that it exists
function isValidEmail(value){
	var pattern = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	if(pattern.test(value)){
		return true;
	}else{
		return false;
	}
}

// Function to make sure password isn't too short
function isTooShort(value){
	var length = value.length;
	if(length < min){
		return true;
	}else{
		return false;
	}
}

// Function to make sure password isn't too long
function isTooLong(value){
	var length = value.length;
	if(length > max){
		return true;
	}else{
		return false;
	}
}
/* END GENERAL VALIDATION FUNCTIONS */

/* FUNCTIONS TO DO LIVE VALIDATION OF EMAIL/PASSWORD */
// Function to make sure the email is valid while they type
// Returns true if valid false if not and sets the objects border

function validate_email(obj){
	var value = obj.val();
	if(isValidEmail(value)){
		obj.css("border-color",valid_color);
		return true;
	}else{
		obj.css("border-color",invalid_color);
		return false;
	}
}

// Function to make sure password isn't too long or short while they type
// Returns true if valid false if not
function validate_pass(obj){
	var length = obj.val().length;
	if(length > min && length < max){
		obj.css("border-color",valid_color);
		return true;
	}else{
		obj.css("border-color",invalid_color);
		return false;
	}
}

// Function to make sure a field isn't blank
// Returns true if valid false if not
function validate_presence(obj){
	var length = obj.val().length;
	if(length == 0){
		obj.css("border-color",invalid_color);
		return false;
	}else{
		obj.css("border-color",valid_color);
		return true;
	}
}

/* FUNCTIONS TO DO LIVE VALIDATION OF EMAIL/EMAIL Confirmation */
// Function to make sure there is something in a field
// Returns false if there is nothing there, true if something is there
//	Also changes the border color, error message, and error class
function validate_presence_with_error(selector){
	var blank = "can't be blank"
	var error_div = $(selector+"-alert");
	var error = ""
	if(!validate_presence($(selector))){
		error = blank;
	}
	return set_error(error,error_div,false);
}

// Function to make sure the email is valid while they type
// Returns true if valid false if not
//	Also changes border color, error message, and error class
function validate_email_with_error(selector){
	var obj = $(selector);
	var error_div = $(selector+"-alert");
	var error = "";
	if(validate_presence(obj)){
		if(!validate_email(obj)){
			error = "is not a valid email";
		}
	}else{
		error = "can't be blank";
	}
	return set_error(error,error_div,false);
}

// Function to make sure the email is valid while they type
// Returns true if valid false if not
//	Also changes border color, error message, and error class
function validate_password_with_error(selector){
	var obj = $(selector);
	var pass = obj.val();
	var error_div = $(selector+"-alert");
	var error = "";
	validate_pass(obj);
	if(isEmpty(pass)){	// Make sure password isn't blank
		error = "can't be blank";
	}else{				// If it's not blank make sure it has the right length
		if(isTooShort(pass)){// Not too short
			error = "is too short. Min length is " + String(min);
		}
		if(isTooLong(pass)){// Not too long
			error = "is too long. Max length is " + String(max);
		}
	}
	return set_error(error,error_div,false);
}

// Function to make sure the phone/fax is valide while they type
// Returns true if valid false if not
//	Also changes border color, error message, and error class
function validate_phone_with_error(selector){
	var obj = $(selector);
	var phone = obj.val();
	var error_div = $(selector+"-alert");
	var error = "";
	if(!(/^\d{7,}$/).test(phone.replace(/[\s()+\-\.]|ext/gi, ''))){
		error = "is not a valid phone number";
	}
	return set_error(error,error_div,false);
}

// Function to determine if two input's values match
// Inputs: selector is original object
// Returns true if they match false if they don't
//	Also changes border color, error message, and error class
function validate_same(selector){
	var obj = $(selector+"_confirmation"); 	// The confirm object
	var target = $(selector);			// The original object
	var error_div = $(selector+"_confirmation-alert");// Where to put the error
	var value = obj.val();
	var match = target.val();
	var error = "";
	if(value != match){
		error = "Something's wrong";
		obj.css("border-color",invalid_color);
	}else{
		if(match == ""){
			error = " ";
		}else{
			obj.css("border-color",valid_color);
		}
	}
	return set_error(error,error_div,true);
}

// Function to determine set the error and error class
function set_error(error,error_div,isSuccess){
	var valid = true;
	if(error != ""){		// We have an error message
		if(error != " "){
			error_div.addClass(alert_class); // Set the error class
		}
		error_div.removeClass(success_class);// Set success class
		valid = false;		// Make sure we do nothing more
	}else{
		error_div.removeClass(alert_class);// Remove error class
		error_div.addClass(success_class);// Add success class
		if(isSuccess){
			error = suc_message;
		}
	}
	error_div.html(error);
	return valid;
}

// Function to set live validations for emails or passwords
// inputs: selector is the selector for the input, isEmail is a boolean
//	true if it's an email validation false if it's password
function set_validations(selector,isEmail){
	if(isEmail){
		$(selector).on('keyup blur change',function(){
			validate_email_with_error(selector);
		});
	}else{
		$(selector).on('keyup blur change',function(){
			validate_password_with_error(selector);
		});
	}
	$(selector+"_confirmation").on('keyup blur change',function(){
		validate_same(selector);
	});
}

/* END LIVE VALIDATION FUNCTIONS */
