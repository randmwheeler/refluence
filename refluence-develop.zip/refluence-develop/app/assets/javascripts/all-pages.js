// Function to determine if a selector exists
$.fn.exists = function(){
	return this.length !== 0;
}

/* All functions that need to be run on all pages */

function goto_link(element){
	var link = element.find("a:first");
	if(link.exists()){
		link[0].click();
	}
}
function add_editor(){
	tinymce.remove();
	tinymce.init({selector : "textarea.edit_here",plugins: "link"});
}

// This function will set the size of the social image icons
function set_social_icons(){
	$(".social-header").each(function(){
		var size = $(this).children(".name").first().height()
		var img = $(this).children(".social-icon").first()
		img.height(size)
		img.width(size)
	});
}

function hide_link_options(){
	if($(".mce-reset").length){
		$(".mce-label").each(function(){
			var name = $(this).html()
			if(name == "Title" || name == "Target"){
				var ref = $(this).prop("id");
				var id = ref.substring(0,ref.lastIndexOf("-"));
				$(this).hide();
				var what = $("#"+id);
				what.hide();
			}
		});
		setTimeout(function(){hide_link_options();},1000);
	}else{
		setTimeout(function(){hide_link_options();},1000);
	}
}

function fix_body(){
	if(!$("#nav-bar").length){ 	// There is no navbar
		$("body").css("padding-top","0px"); 	// Remove padding from body
		$("main").css("margin-top","0px");		// Remove margin from main
	}else{
		$(".menu-btn").on("click",function(){
			goto_link($(this));
		});	// Make sure to go to buttons link if it exists
	}
	$("button .close").attr("aria-hidden", "true");
	add_editor();
	hide_link_options();
	set_social_icons();
}

$(document).ready(fix_body);
$(document).on('page:load',fix_body);
/* // Remove work around for bootstrap and tinymce
$(document).on('focusin', function(e) {
	var ua = navigator.userAgent, m = ua.match(/chrome/i);
	if(m != null){
	    if ($(event.target).closest(".mce-window").length) {
	        e.stopImmediatePropagation();
	    }
	}else{
		var e = window.event || e;
		var targ = e.target || e.srcElement;
	    if ($(targ).closest(".mce-window").length) {
	        e.stopImmediatePropagation();
	    }
	}
});
*/