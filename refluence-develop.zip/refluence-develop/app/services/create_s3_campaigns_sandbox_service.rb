require 'vfs'
require 'vos'
require 'vos/drivers/s3'

class CreateS3CampaignsSandboxService
  def call
    # Initialize S3 driver
    driver = Vos::Drivers::S3.new \
      access_key_id:      Rails.application.secrets.amazon_s3_campaigns_bucket_key,
      secret_access_key:  Rails.application.secrets.amazon_s3_campaigns_bucket_secret,
      bucket:             Rails.application.secrets.amazon_s3_campaigns_bucket_name
    $campaignsBox = Vos::Box.new driver
  end
end