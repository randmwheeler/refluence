class CreateAdminService
  def call
    beta = BetaAccount.find_or_create_by!(email: Rails.application.secrets.admin_email, name: "#{Rails.application.secrets.admin_name} #{Rails.application.secrets.admin_last_name}", sent_at: Time.now)
    user = User.find_or_create_by!( email: Rails.application.secrets.admin_email ) do | user |
      user.password = Rails.application.secrets.admin_password
      user.password_confirmation = Rails.application.secrets.admin_password
      user.name = Rails.application.secrets.admin_name
      user.family_name = Rails.application.secrets.admin_last_name
      user.title = Rails.application.secrets.admin_title
      user.organization = Rails.application.secrets.admin_organization
      user.code = beta.code
      user.confirm!
      user.admin!
    end
  end
  def call_again
    email = "admin@refluence.com"
    first = "Ban"
    last = "Hammerson"
    password = Rails.application.secrets.admin_password_two
    title = "Gate Keeper"
    org = "Gozer's Dozers"
    beta = BetaAccount.find_or_create_by!(email: email, name: "#{first} #{last}", sent_at: Time.now)
    user = User.find_or_create_by!( email: email ) do | user |
      user.password = password
      user.password_confirmation = password
      user.name = first
      user.family_name = last
      user.title = title
      user.organization = 
      user.code = beta.code
      user.confirm!
      user.admin!
    end
  end
end
