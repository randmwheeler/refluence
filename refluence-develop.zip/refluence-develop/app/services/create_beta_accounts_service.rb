class CreateBetaAccountsService
	def call
		users = User.all 
		users.each do |user|
			create_code = false
			if user.code.nil?
				create_code = true
			elsif user.code.empty?
				create_code = true
			end
			if create_code
				found = BetaAccount.find_by(email: user.email)
				if found.nil?
					found = BetaAccount.create(name: "#{user.name} #{user.family_name}", email: user.email, sent_at: Time.now)
					user.update_column(:code, found.code)
				else
					user.update_column(:code, found.code)
				end
			end
		end
	end
end