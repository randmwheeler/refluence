require 'vfs'
require 'vos'
require 'vos/drivers/s3'

class CreateS3AssetsSandboxService
  def call
    # Initialize S3 driver
    driver = Vos::Drivers::S3.new \
      access_key_id:      Rails.application.secrets.amazon_s3_assets_bucket_key,
      secret_access_key:  Rails.application.secrets.amazon_s3_assets_bucket_secret,
      bucket:             Rails.application.secrets.amazon_s3_assets_bucket_name
    $assetsBox = Vos::Box.new driver
  end
end