class CreateRecommendationsService
	def call
=begin
		# Full list of all subindustries
		fin_subs = ["Accident & Health Insurance","Asset Management","Closed-End Fund - Debt","Closed-End Fund - Equity",
			"Closed-End Fund - Foreign","Credit Services","Diversified Investments","Foreign Money Center Banks",
			"Foreign Regional Banks","Insurance Brokers","Investment Brokerage - National","Investment Brokerage - Regional",
			"Life Insurance","Money Center Banks","Mortgage Investment","Property & Casualty Insurance","Property Management",
			"REIT - Diversified","REIT - Healthcare Facilities","REIT - Hotel/Motel","REIT - Industrial","REIT - Office",
			"REIT - Residential","REIT - Retail","Real Estate Development","Regional - Mid-Atlantic Banks",
			"Regional - Midwest Banks","Regional - Northeast Banks","Regional - Pacific Banks","Regional - Southeast Banks",
			"Regional - Southwest Banks","Savings & Loans","Surety & Title Insurance"]
=end
		# Partial list of subs so we have 10 per sub
		fin_subs =  ["Accident & Health Insurance","Asset Management","Closed-End Fund - Debt","Closed-End Fund - Equity","Closed-End Fund - Foreign"]
		fin_handles = ["wolfendale1","moneymorning","sebastiengaly","kitjuckes","Pawelmorski","interfluidity","karleeter",
			"ColinTWilliams","irenealdridge","aaampblog","AwesomeFinance","CoryRichards","Nouriel","TimHartford",
			"finance_wire","Benchu","lagarde","allessiorastani","finplan","susanweiner","loral","lewisfinancial",
			"financialtimes","daily_finance","wealthfront","allanschoenberg","moneyning","michaelkitces","economyUS",
			"qfinance","investopedia","cbsmoneywatch","yahoofinance", "CarlBialik","MONEY","BethKobliner","cnbcnow",
			"tim","deborahgage","xconomy","karlenesinrob","fianancefeed","sunfinancial","nasba","cfopub","davidkwaltz",
			"earningsreports","thestreet","nyseeuronext","mint","calculatedrisk","retheauditors","ryanavent"]
=begin
		tech_subs = ["Application Software","Business Software & Services","Communication Equipment","Computer Based Systems",
			"Computer Peripherals","Data Storage Devices","Diversified Communication Services","Diversified Computer Systems",
			"Diversified Electronics","Healthcare Information Services","Information & Delivery Services",
			"Information Technology Services","Internet Information Providers","Internet Service Providers",
			"Internet Software & Services","Long Distance Carriers","Multimedia & Graphics Software",
			"Networking & Communication Devices","Personal Computers","Printed Circuit Boards","Processing Systems & Products",
			"Scientific & Technical Instruments","Security Software & Services","Semiconductor - Broad Line",
			"Semiconductor - Integrated Circuits","Semiconductor - Specialized","Semiconductor Equipment & Materials",
			"Semiconductor- Memory Chips","Technical & System Software","Telecom Services - Domestic",
			"Telecom Services - Foreign","Wireless Communications"]
=end
		# Partial list of subs so we have 10 per sub
		tech_subs = ["Application Software","Business Software & Services","Communication Equipment","Computer Based Systems","Computer Peripherals"]
		tech_handles = ["scottmonty","steverubel","jbell99","karaswisher","rachelhaot","musatariq","barrielstricker",
			"peretti","tessabarrera","teddygoff","Ekaterina","hugh_w_forrest","davewiner","benparr","bill_gross",
			"mashable","timoreilly","realdanlyons","gartenberg","scobleizer","VanessaOConnell","davemcclure",
			"nytimestech","EntryLevelRebel","venturebeat","sarahneedleman","qhardy","techcrunch","jeff_haden",
			"JohnAguiar","paulbarron","BarrettAll","guykawaski","werner","benioff","jeffbarr","ruv","randybias",
			"hightechdad","davidlinthicum","dana_gardner","jamesurquhart","bobgourley","revodavid","klintron",
			"gigabarb","kristennicole2","dhinchcliffe","jamet123","kdnuggets","carachan1","jeromejarre","harto"]
		tech = Industry.find_or_create_by(name: "Technology")
		fin = Industry.find_or_create_by(name: "Financial")
		final_count = 0
		total_count = 0
		max_per = fin_handles.count / fin_subs.count
		fin_subs.each do |sub|
			new_sub = Subindustry.find_or_create_by(name: sub,industry_id: fin.id)
			max = max_per
			if sub == fin_subs.last
				max = fin_handles.count - total_count
			end
			0.upto max-1 do |index|
				new_rec = IndustryRecommendation.find_or_create_by(name: fin_handles[total_count+index],subindustry_id: new_sub.id)
			end
			total_count = total_count + max-1
		end
		final_count = total_count
		total_count = 0
		max_per = tech_handles.count / tech_subs.count
		tech_subs.each do |sub|
			new_sub = Subindustry.find_or_create_by(name: sub,industry_id: tech.id)
			max = max_per
			if sub == tech_subs.last
				max = tech_handles.count - total_count
			end
			0.upto max-1 do |index|
				new_rec = IndustryRecommendation.find_or_create_by(name: fin_handles[total_count+index],subindustry_id: new_sub.id)
			end
			total_count = total_count + max-1
		end
		final_count = final_count + total_count + 2
	end
end