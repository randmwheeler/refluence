class CreateSubscriptionsService
  def call
    Subscription::PLANS.each do |subscription|
      sub = Subscription.find_or_create_by!( name: subscription.name ) do | sub |
        sub.name = subscription.name
        price = "#{subscription.amount}"
        price = price.insert(-3, '.') #Add decimal to convert to currency string
        sub.price = ActionController::Base.helpers.number_to_currency(price)
        sub.admins = 1 #always one admin
        plan_type = sub.name.split(' ')[0].downcase
        sub.send(plan_type)
        sub.save
      end
    end
    count = Subscription::PLANS.count
  end
end
