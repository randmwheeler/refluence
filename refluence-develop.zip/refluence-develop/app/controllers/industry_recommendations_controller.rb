class IndustryRecommendationsController < ApplicationController
  before_action :set_industry_recommendation, only: [:show, :edit, :update, :destroy]

  def update
  	if industry_recommendation_params[:spare_me] == "shark"
  		@refluencers = IndustryRecommendation.where(subindustry_id: industry_recommendation_params[:subindustry], opted_out: [false, nil]).where("handle != ?","").order("score DESC")
  		@count = @refluencers.count
	  	respond_to do |format|
	  		format.js
	  	end
	end
  end

  private
  	def set_industry_recommendation
  		@industry_recommendation = IndustryRecommendation.find(params[:id])
  	end

  	    # Never trust parameters from the scary internet, only allow the white list through.
    def industry_recommendation_params
      params.require(:industry_recommendation).permit(:subindustry, :name, :numeric_id, :handle, :location, :follower_count,
      	:following_count, :tweet_count, :favorites_count, :listed_count, :score, :profile_image_url, :source_id, :spare_me)
    end
end
