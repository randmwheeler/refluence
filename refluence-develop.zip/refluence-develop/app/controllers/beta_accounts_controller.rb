class BetaAccountsController < ApplicationController
	before_action :set_beta_account, only: [:show, :edit, :update, :destroy]

	def index
		if current_user.nil?
			redirect_to root_path
		else
			if !current_user.admin?
				if !current_user.brand.nil?
					redirect_to brand_releases_path(current_user.brand)
				else
					redirect_to root_path
				end
			else
				@to_send = BetaAccount.where(sent_at: nil)
				@beta_users = BetaAccount.where(used: true)
				## CODE TO SEND STUFF
				if !params[:selects].nil?
					if params[:selects].any?
						params[:selects].each do |select|
							if select != ""
								@beta = BetaAccount.find select.to_i
								if !@beta.nil?
									if @beta.sent_at.nil?
										UserMailer.beta_email(@beta).deliver
										@beta.update_column(:sent_at, Time.now)
									end
								end
							end
						end
					end
				end
			end
		end
	end

	# POST /beta_accounts
	# POST /helps.json
	def create
		@beta = BetaAccount.new(beta_params)

		respond_to do |format|
			if @beta.save
				format.html { redirect_to new_user_session_path, notice: 'You are now on the list to get a beta account. You will recieve an email once you have been approved.' }
				format.json { render :show, status: :created, location: @beta }
			else
				messages = ""
				@beta.errors.full_messages.each do |error|
					messages << error
				end
				format.html { redirect_to new_user_session_path, notice: "#{messages}" }
				format.json { render json: @beta.errors, status: :unprocessable_entity }
			end
		end
	end

	def destroy
		@beta.destroy
		respond_to do |format|
      format.html { redirect_to beta_accounts_path }
      format.json { head :no_content }
    end
	end

	private
	    # Never trust parameters from the scary internet, only allow the white list through.
	    def beta_params
	      params.require(:beta_account).permit(:email,:name)
	    end

		def set_beta_account
			@beta = BetaAccount.find(params[:id])
		end
end