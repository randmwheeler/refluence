class SubscriptionsController < ApplicationController
  
	# GET /subscriptions
	# GET /subscriptions.json
	def index
		@subscriptions = Subscription.order(level: :asc)
	end

	def new
	end

	def create
		current_user.subscription = Subscription.find_by_name(params[:plan])
		current_user.save
		redirect_to select_dashboard_path

		# Temporarily circumvent Stripe. Remove lines above and uncomment lines below to reintegrate Stripe. 
		# Also uncomment Stripe buttons in view

		# # creates subscription based on what plan was selected
		# # if user does not have a stripe customer id yet (meaning they haven't bought anything)
		# # create a new stripe customer and give them a subscription
		# if current_user.stripe_customer_id.nil? || current_user.stripe_customer_id.empty?
		# 	customer = Stripe::Customer.create(
		# 	  :email => current_user.email,
		# 	  :card => params[:stripeToken],
		# 	  :plan => params[:plan].split(' ')[0].downcase
		# 	)
		# 	#save customer id and subscription to current user
		# 	current_user.stripe_customer_id = customer.id
		# 	current_user.stripe_subscription_id = customer.subscriptions.first.id
		# 	current_user.save
		# # Else, they have an id, and we need to check if they have a subscription, 
		# # and either upgrade or give them a new one
		# else
		# 	customer = Stripe::Customer.retrieve(current_user.stripe_customer_id)
		# 	if current_user.stripe_subscription_id.nil? || current_user.stripe_subscription_id.empty?	#if customer has no subscription, create one
		# 		customer.subscriptions.create(:plan => params[:plan])
		# 		current_user.stripe_subscription_id = customer.subscriptions.first.id
		# 		current_user.save
		# 	else
		# 		subscription = customer.subscriptions.retrieve(current_user.stripe_subscription_id)
		# 		subscription.plan = params[:plan].split(' ')[0].downcase
		# 		subscription.save
		# 	end
		# end
		# current_user.subscription = Subscription.find_by_name(params[:plan])
		# current_user.save	
		# redirect_to select_dashboard_path


		# rescue Stripe::CardError => e
		# 	flash[:error] = e.message
		# 	redirect_to select_subscription_path
			
		# rescue Stripe::InvalidRequestError => e
		# 	customer = Stripe::Customer.create(
		# 	  :email => current_user.email,
		# 	  :card => params[:stripeToken],
		# 	  :plan => params[:plan].split(' ')[0].downcase
		# 	)
		# 	#save customer id and subscription to current user
		# 	current_user.stripe_customer_id = customer.id
		# 	current_user.stripe_subscription_id = customer.subscriptions.first.id
		# 	current_user.subscription = Subscription.find_by_name(params[:plan])
		# 	current_user.save
		# 	if current_user.brands.nil?
		# 		redirect_to select_dashboard_path
		# 	else
		# 		redirect_to current_user.brand.first_path
		# 	end
	end

	def downgrade
		@plan = Subscription.find(params[:plan])
	end
end
