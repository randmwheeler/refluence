class RegistrationsController < Devise::RegistrationsController
  before_filter :update_sanitized_params, if: :devise_controller?

  def update_sanitized_params
    devise_parameter_sanitizer.for(:sign_up) {|u| u.permit(:name, :email, :password, :password_confirmation,:family_name,:title,:organization,:hopes, :code)}
    devise_parameter_sanitizer.for(:account_update) {|u| u.permit(:name, :email, :password, :password_confirmation, 
    	:current_password,:family_name,:title,:organization,:hopes,:subscription,:role,:time_zone)}
  end

  def update
    has_subscription = false
    error = false
    # For Rails 4
    account_update_params = devise_parameter_sanitizer.sanitize(:account_update)
    # For Rails 3
    # account_update_params = params[:user]

    # required for settings form to submit when password is left blank
    if account_update_params[:password].blank?
      account_update_params.delete("password")
      account_update_params.delete("password_confirmation")
    else
      # Only check for password match if password has changed
      if current_user.valid_password? account_update_params[:password]
        # If it matches then remove them
        account_update_params.delete("password")
        account_update_params.delete("password_confirmation")
      end
    end

    # Make sure the user enters their password in to edit their account
    if account_update_params.has_key? "current_password"
      if !current_user.valid_password? account_update_params[:current_password]
        error = true
      end
      account_update_params.delete("current_password")
    end

    # update the subscription to be an int
    if !account_update_params[:subscription].blank?
    	has_subscription = true
    	account_update_params[:subscription] = account_update_params[:subscription].to_i
    end

    @user = User.find(current_user.id)
    if error
      current_user.errors.add(:current_password, "does not match")
      redirect_to "/users/edit"
    else
      if @user.update_attributes(account_update_params)
        set_flash_message :notice, :updated
        # Sign in the user bypassing validation in case their password changed
        sign_in @user, :bypass => true
        if has_subscription
          redirect_to select_dashboard_path
        else
          redirect_to after_update_path_for(@user)
        end
      else
        render "edit"
      end
    end
  end

end
