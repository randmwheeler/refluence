class PagesController < ApplicationController
  def index
  end

  def our_story
  end

  def pricing
  end

  def how_it_works
  end

  def investor_information
  end

  def help_and_support
  end

  def faqs
  end

  def our_team
  end

  def about
  end

  def contact
  end

  def wiki
  end

  def terms
  end

  def privacy
  end

  def copyright
  end

  def stats
    @twitter_id = params[:id] || 24611229

    # Number of Followers
    @url = "http://refluence.correlate.io/clj/refluence/twitter/#{@twitter_id}/followers?apikey=#{Rails.application.secrets.correlate_api_key}"
    @followers = JSON.load open @url

    # Number of Following
    @url = "http://refluence.correlate.io/clj/refluence/twitter/#{@twitter_id}/friends?apikey=#{Rails.application.secrets.correlate_api_key}"
    @friends = JSON.load open @url

    # Number of Tweets
    # Number of Favorites
    # Number of Listed
    # Profile IDs of the followers
    # Profile IDs of the people the user is following

  end
end
