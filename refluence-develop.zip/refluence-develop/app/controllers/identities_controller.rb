class IdentitiesController < ApplicationController
	before_action :set_identity, only: [:destroy]

	def update
		@identities = params[:brand][:identity_ids]
		@brand = Brand.find(5)
		@brand.identities.clear
		@identities.each do |identity|
			if !identity.empty?
				@brand.identities << Identity.find(identity)
			end
		end
		@brand.save
		redirect_to brand_releases_path(@brand)
	end

  # DELETE /identities/1
  # DELETE /identities/1.json
  def destroy
    @identity = Identity.find(params[:id])
    auths = BrandAuthentication.where(identity_id: @identity.id)
    auths.each do |auth| 	# Destroy all brand identites related to this identity
    	auth.destroy
    end
    @identity.destroy 		# Destroy this identity
    # Destroy all related agency stuff
    respond_to do |format|
      format.html { redirect_to "/users/edit" }
      format.json { head :no_content }
    end
  end

  private
  	def set_identity
      @identity = Identity.find(params[:id])
    end

    def identity_params
      params.require(:identity).permit(:user, :provider, :uid, :token, :secret, :username)
    end
end
