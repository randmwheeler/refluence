class ApplicationController < ActionController::Base
	include Pundit
	before_filter :mailer_set_url_options
	# Prevent CSRF attacks by raising an exception.
	# For APIs, you may want to use :null_session instead.
	protect_from_forgery with: :exception

	# Old CanCan version
  	rescue_from CanCan::AccessDenied do |exception|
		current_user.nil? ?	message = "#{exception.message} Please log in first." : message = exception.message
		redirect_to "/", :alert => message
	end
	
	rescue_from ActionController::InvalidAuthenticityToken do |exception|
		respond_to do |format|
			format.js 	{ render :js => "window.location = '/login'"}
			format.html { redirect_to '/login'}
		end
	end

	#after_action :verify_authorized, :except => :index
	#after_action :verify_policy_scoped, :only => :index

	# Display the user not authorized error if user is not authorized
	rescue_from Pundit::NotAuthorizedError, with: :user_not_authorized

	# Make sure to send user to the select dashboard after they sign in
	def after_sign_in_path_for(resource)
		if current_user.subscription.nil?
			select_subscription_path
		else
			if !current_user.brand.nil?
				brand_releases_path(current_user.brand)
			else
				select_dashboard_path
			end
		end
=begin
		sign_in_url = url_for(:action => 'new', :controller => 'sessions', :only_path => false, :protocol => 'http')
		if request.referer == sign_in_url
			super
		else
			
			#stored_location_for(resource) || request.referer || root_path
		end
=end
	end

	def ensure_signup_complete
	    # Ensure we don't go into an infinite loop
	    return if action_name == 'finish_signup'

	    # Redirect to the 'finish_signup' page if the user email hasn't
	    # yet been verified
	    if current_user && !current_user.email_verified?
	      redirect_to finish_signup_path(current_user)
	    end
 	end

	private
		# Old function to determine if login is required not needed just use authenticate_user!
		def require_login
			if current_user.nil?
				valid_paths = [root_path, login_path, create_account_path, recover_password_path, user_confirmation_path, 
					new_user_confirmation_path, new_user_session_path, user_session_path, user_password_path,
					new_user_password_path];
				index = valid_paths.index request.path 
				if index.nil?
					redirect_to login_path
				end
			end
		end

		# Function to flash an unauthorized message for a user
		def user_not_authorized
			policy_name = exception.policy.class.to_s.underscore

			flash[:error] = I18n.t "pundit.#{policy_name}.#{exception.query}",
				default: 'You cannot perform this action.'
			redirect_to(request.referrer || root_path)
		end

		# Dynamic mailer options setting based on current host
		def mailer_set_url_options
		  ActionMailer::Base.default_url_options[:host] = request.host_with_port
		end
end
