class AgencyImagesController < ApplicationController
  before_action :set_agency_image, only: [:show, :edit, :update, :destroy]
  before_filter :authenticate_user!

  # GET /agency_images
  # GET /agency_images.json
  def index
    #@agency_images = AgencyImage.where(agency_id: Agency.where(user_id: current_user.id).uniq.pluck(:id))
    if current_user.brand.nil?
      redirect_to select_dashboard_path  
    else
      @agency_images = AgencyImage.where(agency_id: current_user.brand.agency.id)
    end
  end

  # GET /agency_images/1
  # GET /agency_images/1.json
  def show
  end

  # GET /agency_images/new
  def new
    @agency_image = AgencyImage.new
  end

  # GET /agency_images/1/edit
  def edit
  end

  # POST /agency_images
  # POST /agency_images.json
  def create
    @agency_image = AgencyImage.new(agency_image_params)
    @agency_image.agency = current_user.brand.agency 

    respond_to do |format|
      if @agency_image.save
        format.html { redirect_to @agency_image, notice: 'Agency Asset was successfully created.' }
        format.json { render :show, status: :created, location: @agency_image }
      else
        format.html { render :new }
        format.json { render json: @agency_image.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /agency_images/1
  # PATCH/PUT /agency_images/1.json
  def update
    respond_to do |format|
      if @agency_image.update(agency_image_params)
        format.html { redirect_to @agency_image, notice: 'Agency Asset was successfully updated.' }
        format.json { render :show, status: :ok, location: @agency_image }
      else
        format.html { render :edit }
        format.json { render json: @agency_image.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /agency_images/1
  # DELETE /agency_images/1.json
  def destroy
    @agency_image.destroy
    respond_to do |format|
      format.html { redirect_to agency_images_url, notice: 'Agency Asset was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_agency_image
      @agency_image = AgencyImage.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def agency_image_params
      params.require(:agency_image).permit(:agency_id,:image,:logo)
    end
end
