class BrandAuthenticationsController < ApplicationController
	before_action :set_brand_authentication, only: [:destroy]
	before_filter :authenticate_user!

	def destroy
		@brand = @brandauth.brand
		if !@brandauth.identity.nil?
			@brandauth.identity.destroy
		end
		@brandauth.destroy
		redirect_to brand_releases_path(@brand), :notice => "Social Account deleted."
	end

	private
		def set_brand_authentication
			@brandauth = BrandAuthentication.find(params[:id])
		end
end
