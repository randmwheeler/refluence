class ReleasesController < ApplicationController
  before_action :set_release, only: [:show,:view, :tweet, :edit, :update, :destroy]
  skip_before_action :verify_authenticity_token, only: [:index,:show]
  before_filter :get_brand
  before_filter :authenticate_user!
  before_action :check_sub

  def get_brand
    if current_user.nil?
      @brand = nil
    else
      error = false
      if Brand.exists?(params[:brand_id])
        @brand = Brand.find(params[:brand_id])
        # ALL ACCESS RIGHTS FOR BRANDS SHOULD GO HERE
        if @brand.agency.user != current_user
          redirect_to select_dashboard_path, :alert => "You can't access this dashboard."
        else
          current_user.update_column(:brand_id,@brand.id)
        end
      else
        redirect_to select_dashboard_path, :alert => "Brand named #{params[:brand_id]} does not exist."
      end
    end
  end

  # GET /releases
  # GET /releases.json
  def index
    if !@brand.nil? # Just get any release template for this brand
      @template = Release.find_by(brand_id: @brand.id, isTemplate:true)
      if @template.nil? # If there are none create the first blank one
        @template = Release.create(creator_id: current_user.id,brand_id: @brand.id, isTemplate: true)
        create_release_submodels @template, nil
      end
    end
    @rel, days = nil, 69    # Release to search for nil is just everything and previous days data to search

    @releases = @brand.releases.where("status != ?", Release.statuses[:template]) # Only look at active releases
    #@templates = @brand.releases.where(isTemplate: true) # Templates for new
    @nils = @brand.releases.where(status: nil)
    @nils.each do |nully|
      nully.draft!
    end
    @releases.reload
    @templates = @brand.releases.where(status: Release.statuses[:template])
    @drafts = @releases.where(status: Release.statuses[:draft])
    @approves = @releases.where(status: Release.statuses[:approved])
    @actives = @releases.where(status: Release.statuses[:active]).order(:start_date)
    @archives = @releases.where(status: Release.statuses[:archived])
    @retires = @releases.where(status: Release.statuses[:retired])

    @social_accounts = BrandAuthentication.where(brand_id: @brand.id)
    @identities = Identity.where(user_id: current_user.id)
    @user_releases_count = Release.where(creator_id: current_user.id, isTemplate: false).count

    # Get the values from search
    if params[:release_type].present? # The release type to search on
      @type = Release.retypes[params[:release_type]]
    end
    if params[:release_search].present? # The number of days to search for (69 is sentinal to get all values)
      if params[:release_search] != "69"
        days = params[:release_search].to_i
      end
      dayz = params[:release_search].to_i
    end
    if params[:release_release].present?
      @rel = Release.find_by(id: params[:release_release])
    end
    @data = create_fake_data_per_release(@type, days)
    #@single = create_single_data @rel
    @single = create_all_data @rel, days
  end

  # GET /releases/1
  # GET /releases/1.json
  def show
  end

  # GET /releases/1/view  
  def view
  end

  # GET /releases/new
  def new
    @release = Release.new
  end

  # GET /releases/1/edit
  def edit
  end

  def tweet
    respond_to do |format|
      format.js
    end
  end

  # POST /releases
  # POST /releases.json
  def create
    release_id = 0
    if !params[:release].nil? # Normal create page
      release_id = params[:release][:release_id].to_i # Get the release id from the page
    end
    paras = release_params
    if !paras[:release_id].nil? # Remove the release_id if it exists
      paras.delete :release_id
    end
    @release = Release.new(paras)         # Go ahead and build a new release with current paramaters
    @release.creator = current_user       # Set the creator to the current user
    @release.brand = @brand               # Set the brand of the release to current brand

    if release_id != 0                    # If it's not zero it's a release id
      release_to_copy = Release.find_by(id: release_id)# Get the release we wish to copy
      if !release_to_copy.nil?            # Make sure that we don't try to copy a nil
        @release.copy_it(current_user,release_to_copy) # Make the copy for the current user
      end
    end
    respond_to do |format|
      if @release.save
        create_release_submodels @release, release_to_copy
        # If the save was good (shouldn't ever fail) then let the user start editing it
        format.html { redirect_to edit_brand_release_path(@brand,@release), notice: 'Release was successfully created.' }
        format.json { render :show, status: :created, location: brand_release_path(@brand,@release) }
        format.js
      else
        format.html { render :new }
        format.json { render json: @release.errors, status: :unprocessable_entity }
        format.js
      end
    end
  end

  # PATCH/PUT /releases/1
  # PATCH/PUT /releases/1.json
  def update
    @data = {}
    @state = ""
    has_distributed = false   # Make sure to create published copy after distribution form
    paras = release_params    # Make a local copy of release parameters
    if !paras[:retype].nil?
      if paras[:retype] != ""
        paras[:retype] = release_params[:retype].to_i # Make sure the type is an int
      end
    end
    if !paras[:publish].nil?  # If we got the publish attribute
      @state = paras[:publish]
      if paras[:publish] == "publish" # And it's publish
        if !@release.isTemplate       # Only make active if not a template
          @release.active!            # make this release active
          # Make sure we only have the published copy available if it's active
          if @release.started?
            @release.update_column(:published,true)
          else
            a = @release.brand.agency
            p a
            p a.campaigns
            @release.brand.agency.campaigns[@release.slug].write ""
          end
        end
      end
      paras.delete :publish           # Remove that parameter so we can save
    end
    if !paras[:import].nil?   # We got the import stuff to add to an audience
      if !paras[:recommended].nil? # We have both sets for import
        # SET UP AUDIENCE HERE
        update_audience(@release.audience,paras[:recommended],paras[:import])
        paras.delete :recommended
      end
      paras.delete :import    # Remove this parameter now that we don't need it
    end
    if !paras[:name].nil?
      paras[:name] = paras[:name].gsub(/'/,"`")
    end
    if !paras[:content_attributes].nil?
      if !paras[:content_attributes][:copy].nil?
        paras[:content_attributes][:copy] = paras[:content_attributes][:copy].gsub(/(\r\n+)/,"")    # Remove end lines from copy
        paras[:content_attributes][:copy] = paras[:content_attributes][:copy].gsub(/'/,"`")         # Replace single quotes to not break javascript
      end
      if !paras[:content_attributes][:headline].nil?
        paras[:content_attributes][:headline] = paras[:content_attributes][:headline].gsub(/'/,"`");# Replace single quoates to not break javascript
      end
    end
    if !paras[:audience_attributes].nil?
      if !paras[:audience_attributes][:industry].nil?
        paras[:audience_attributes][:industry] = Industry.find_by(id: paras[:audience_attributes][:industry])
      end
      if !paras[:audience_attributes][:subindustry].nil?
        paras[:audience_attributes][:subindustry] = Subindustry.find_by(id: paras[:audience_attributes][:subindustry]) 
      end
    end
    if !paras[:logo].nil?
      paras[:logo] = AgencyImage.find_by(id: paras[:logo])
    end
    if !paras[:status].nil?
      if paras[:status] != ""
        paras[:status] = paras[:status].to_i 
        if paras[:status] == Release.statuses[:archived]
          @release.update_column(:status, Release.statuses[:archived]) # Archive this anyway
        end
      end
    end
    if !paras[:distribution_attributes].nil?
      if !paras[:distribution_attributes][:time_zone].nil?
        if paras[:distribution_attributes][:time_zone] != ""
          if paras[:distribution_attributes][:start_date] != ""
            paras[:distribution_attributes][:start_date] = ActiveSupport::TimeZone[paras[:distribution_attributes][:time_zone]].parse(paras[:distribution_attributes][:start_date])
          end
        end
      end
      if !paras[:distribution_attributes][:social].nil?
        paras[:distribution_attributes][:social] = Utility.clean_array paras[:distribution_attributes][:social]
        paras[:distribution_attributes][:social] = paras[:distribution_attributes][:social].to_json
      end
      has_distributed = true
      if current_user.state != "normal"
        current_user.normal!      # Make sure to reset the user back to normal status
      end
    end
    if !paras[:headline].nil?
      paras[:headline] = paras[:headline].gsub(/'/,"`")
      if paras[:headline].length > 80
        paras[:headline] = paras[:headline][0,80]
      end
    end
    respond_to do |format|
      if @release.update(paras)
        if has_distributed && !@release.isTemplate # Only create published release if not template
          publish_release @release 
        end
        format.html { redirect_to edit_brand_release_path(@brand,@release), notice: 'Release was successfully updated.' }
        format.json { render :show, status: :ok, location: brand_release_path(@brand,@release)}
        format.js
      else
        format.html { render :edit }
        format.json { render json: @release.errors, status: :unprocessable_entity }
        format.js
      end
    end
  end

  def publish_release release
    a = release.brand.agency
    p a
    p a.campaigns
    release.brand.agency.campaigns[release.slug].write release.published_copy
    client = Bitly.client
    u = client.shorten(release.preview_url)
    release.update_column(:short_url, u.short_url) 
=begin
    # Publish to canonical URL
    a = Agency.find(Brand.find(@release.brand_id).agency_id)
    p a
    p a.campaigns
    @release.brand.agency.campaigns[@release.slug].write @release.published_copy
    #Agency.find(Brand.find(@release.brand_id).agency_id).campaigns[@release.slug].write @release.published_copy
=end
  end

  def create_release_submodels release, release_to_copy
      # Create the content for the release
      if release.content.nil?
        @content = Content.new
        if !release_to_copy.nil?
          if !release_to_copy.content.nil?
            @content.headline = release_to_copy.content.headline
            @content.copy = release_to_copy.content.copy 
            @content.assets = release_to_copy.content.assets
          end
        end 
        @content.release_id = release.id 
        @content.save
      end

      # Create the audience for the release
      if release.audience.nil?
        @audience = Audience.new
        if !release_to_copy.nil?
          if !release_to_copy.audience.nil?
            @audience.industry = release_to_copy.audience.industry
            @audience.subindustry = release_to_copy.audience.subindustry
            @audience.brand = release.brand
            @audience.handles = release_to_copy.audience.handles
            @audience.keywords = release_to_copy.audience.keywords
          end
        end
        @audience.release_id = release.id
        @audience.save
      end

      # Create the contact which may be eventually be removed
      if release.contact.nil?
        @contact = Contact.new
        if !release_to_copy.nil?
          if !release_to_copy.contact.nil?
            @contact.name = release_to_copy.contact.name
            @contact.email = release_to_copy.contact.email
            @contact.phone = release_to_copy.contact.phone
            @contact.fax = release_to_copy.contact.fax
          end
        end
        @contact.release_id = release.id
        @contact.save
      end

      # Create the distribution for the release
      if release.distribution.nil?
        @distribution = Distribution.new 
        @distribution.social = "[]";
        if !release_to_copy.nil?
          if !release_to_copy.distribution.nil? 
            @distribution.time_zone = release_to_copy.distribution.time_zone
            @distribution.social = release_to_copy.distribution.social
          end
        end
        if current_user.time_zone.nil?
          if @distribution.time_zone.nil?
            @distribution.start_date = Time.now.utc  # Set the start date to now (probably needs to be changed)
            @distribution.time_zone = "UTC"          # Default the time zone to utc
          else
            @distribution.start_date = ActiveSupport::TimeZone[@distribution.time_zone].parse(Time.now.to_s)
          end
        else
          @distribution.start_date = ActiveSupport::TimeZone[current_user.time_zone].parse(Time.now.to_s)
          @distribution.time_zone = current_user.time_zone
        end
        @distribution.release_id = release.id 
        @distribution.save
      end
  end

  # DELETE /releases/1
  # DELETE /releases/1.json
  def destroy
    @release.destroy
    if !@release.contact.nil?
      @release.contact.destroy
    end
    if !@release.audience.nil?
      @release.audience.destroy
    end
    if !@release.content.nil?
      @release.content.destroy
    end
    if !@release.distribution.nil?
      @release.distribution.destroy
    end
    respond_to do |format|
      format.html { redirect_to brand_releases_url(@brand) }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_release
      @release = Release.find(params[:id])
    end

    def check_sub
      if current_user.subscription.nil?
        redirect_to select_subscription_path, :alert => "You need to create a subscription before you can access brands."
      end
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def release_params
      params.require(:release).permit(:name,:start_date,:copy,:url, :logo, :status,
       :retype, :headline, :release_id, :publish, :industry, :subindustry, :assets, :isTemplate,
       :time_zone,
       :recommended => [], :import => [], 
       :content_attributes =>[:id,:retype,:headline,:copy,:assets,:release_id],
       :audience_attributes =>[:id,:industry,:subindustry,:keywords],
       :contact_attributes =>[:id,:name,:phone,:fax,:email],
       :distribution_attributes => [:id, :start_date, :end_date, :time_zone, :social => []])
    end

    def update_audience(audience,recommend,handles)
      index = recommend.index ""
      if !index.nil?
        recommend.delete ""
      end
      index = handles.index ""
      if !index.nil?
        handles.delete ""
      end
      found = "{\"recommended\":"
      found << recommend.to_json
      found << ", \"import\": "
      found << handles.to_json
      found << "}"
      audience.handles = found
      audience.save
    end

    def create_fake_data(type,days_before)
      if @releases.nil?
        @releases = @brand.releases.where(isTemplate: false) # Only look at active releases
      end
      if @actives.nil?
        @actives = @releases.where(status: Release.statuses[:active])
      end
      date = Time.now.to_date - days_before       # Get the lower end of date range
      today = Time.now.to_date                    # Get the high end of date range
      max = 300                                   # Max used for random generation
      id = -1                                     # set the id of type sent
      if !type.nil? # If type is nil then look at all active releases
        id = type
        releases = @actives.where(retype: type)   # Search based on current type
      else
        releases = @actives                       # Otherwise just use all of them
      end

      if days_before == 69                               # Reset the days for all
        date = releases.minimum(:start_date).to_date
        range = release.minimum(:start_date).to_date - Time.now.to_date
        days_before = range.to_i
      end

      data_json = "{}"                            # empty set if there is no data
      # Set the basic data hash for all analyitcs
      data = {set: nil, avg: 0,max: 0,min: max, total: 0, count: 0, reach: 0, relevance: 0}
      data[:influencers] = 0                   # Fake the data for influencers and social sources
      @actives.each do |active|
        data[:reach] = data[:reach] + active.reach
        data[:relevance] = data[:relevance] + active.relevance
        data[:influencers] = data[:influencers] + active.influencers
      end
      if !@active.nil?
        data[:reach] = data[:reach]/@active.count
        data[:relevance] = data[:relevance]/@active.count
      end
      first = rand(0..100)
      second = rand(0..(100-first))
      third = 100-first-second
      data[:sources] = {"Social"=> first,"SEO" => second,"PPC" => third}
      data[:source_data] = "[#{first},#{second},#{third}]"
      if !releases.empty?                         # We have some releases so set the json up
        data_json = '[{"id": ' << "#{id}" << ', "days": ' << "#{days_before}" << ', "key": "' << "Total Page Views" << '" , "values": ['
        data[:set] = 1                            # Tell the page data is set for data below graph
        date.upto today do |day|                  # Loop through the dates to get data for
          total_value = 0                         # Total number of page views for current day
          releases.each do |release|              # Loop through all releases
            # Get actual data here
            total_value += rand(1..max)           # Fake some data for each release
          end
          # Set the values 
          if data[:max] < total_value             # Is this the biggest value
            data[:max] = total_value              # Set it and forget it
          end
          if data[:min] > total_value             # Is this the smallest value
            data[:min] = total_value              # Set it and forget it
          end
          data[:total] += total_value             # Add to the total for getting the avg
          data[:count] += 1                       # Add one to count for each day
          data_json << "[ #{day.to_time.to_i}, #{total_value} ]" # Set the data for that day
          if day != today                         # We have more if it's not today
            data_json << ", "                     # Link the arrays
          else
            data_json << "]"                      # Otherwise close outer array
          end
        end
        data[:avg] = data[:total]/data[:count]    # Set the average
        data_json << "}]"                         # Close the json object
      end
      data[:json] = data_json                     # Add it to the data hash
      return data
    end

    def create_single_data release 
      if @actives.nil?
        @actives = Release.where(brand_id: @brand.id, isTemplate: false, status: Release.statuses[:active])
      end
      if release.nil?
        if @actives.any?
          release = @actives.first 
        end
      end
      data = {set: nil, refluencers: 0, delivered:0, views: 0, retweets: 0, favorited: 0, views_json: "{}", retweets_json: "{}", favorited_json: "{}"}
      if !release.nil?
        today_time = ActiveSupport::TimeZone[release.distribution.time_zone].parse(Time.now.to_s)
        today = today_time.to_date
        start_time = release.distribution.start_date
        start_date = start_time.to_date
        if start_date < today
          days = []             # Set the days to be used for views
          data[:set] = true
          max = 300
          hour = start_time
          while hour < today_time
            days.push(hour)
            hour += 1.day
          end
          views_json = "["
          daily = '{ "id": ' << "#{release.id}" << ' ,"yAxis": 1 , "type": "line", "key": "' << release.short_name << '" , "values": ['
          total = '{ "key": "Cumulative Views" ,"yAxis": 1 , "type": "line", "values": ['
          retweets = '{ "key": "Retweets" ,"yAxis": 2 , "type": "line", "values": ['
          favorites = '{ "key": "Favorited" ,"yAxis": 2 , "type": "line", "values": ['
          total_views, total_retweets, total_favorites = 0, 0 ,0
          delta = 3
          reduction = delta
          hour = start_time
          end_time = start_time + 48.hours
          if end_time > today_time
            end_time = today_time
          end
          while hour < today_time
            index = days.index hour
            if !index.nil?
              current_value = rand(0..max)
              total_views += current_value            
              daily << "[ #{hour.to_i}, #{current_value} ]"
              total << "[ #{hour.to_i}, #{total_views} ]"
              if days[index] != days.last
                daily << ", "
                total << ", "
              end
            end
            if hour < end_time
              current_value = rand((max-reduction*2)..(max-reduction))
              total_retweets += current_value
              reduction += delta
              retweets << "[ #{hour.to_i}, #{current_value} ]"          
              current_value = rand(0..max)
              total_favorites += current_value
              favorites << "[ #{hour.to_i}, #{current_value} ]"
              if hour < end_time - 1.hour
                retweets << ", "
                favorites << ", "
              end
            end
            hour += 1.hour
          end
          views_json << daily << "]}, " << total << "]}," << retweets << "]}," << favorites << "]}]"
          data[:views_json] = views_json
          data[:views] = total_views
          data[:retweets] = total_retweets
          data[:favorited] = total_favorites
          data[:delivered] = rand(85..100)
          data[:refluencers] = release.influencers
        end
      end
      return data
    end

    def create_all_data(distribution ,days_before)
      if @releases.nil?     # Make sure we have an array of distributions for this brand
        @releases = @brand.releases.where(isTemplate: false)
      end
      if @actives.nil?      # Make sure we have an array of the active distributions or this brand
        @actives = @releases.where(status: Release.statuses[:active])
      end
      chart_start = Time.now - days_before.days # Get the intial start time to start the graph
      start = chart_start                       # Get the actual lowest start date
      today = Time.now                          # Get today so we know when to stop
      max = 300                                 # Max value for randoms
      releases = []                             # All releases that have started
      if @actives.any?                          # Set the lowest start date and add all active releases that have started
        lowest = today 
        @actives.each do |rel|
          if rel.started?
            releases.push(rel)
            if rel.distribution.start_date < lowest
              lowest = rel.distribution.start_date
            end
          end
        end
        start = lowest
      end
      if distribution.nil?                  # If we didn't get a release then select the first started active distribution
        distribution = releases.first 
      end

      data = {set: nil, refluencers: 0, delivered:0, views: 0, retweets: 0, favorited: 0, all_json: "{}", views_json: "{}", retweets_json: "{}", favorited_json: "{}"}
      if releases.any?                              # Only create the data if there are releases
        if days_before == 69 || start > chart_start # If it's all or the shortest start is greater then chart start, then change chart start
          chart_start = start
        end
        all = "["
        releases.each do |release|
          today_time = ActiveSupport::TimeZone[release.distribution.time_zone].parse(Time.now.to_s)
          today = today_time.to_date
          start_time = release.distribution.start_date
          start_date = start_time.to_date
          display_in_all = true 
          if start_time > today_time - 1.day
            display_in_all = false 
          end
          days = []             # Set the days to be used for views
          data[:set] = true
          max = 300
          hour = start_time
          while hour < today_time
            days.push(hour)
            hour += 1.day
          end
          views_json = "["
          daily = '{ "id": ' << "#{distribution.id}" << ', "days": ' << "#{days_before}" << ' ,"yAxis": 1 , "type": "line", "key": "' << release.short_name << '" , "values": ['
          total = '{ "key": "Cumulative Views" ,"yAxis": 1 , "type": "line", "values": ['
          retweets = '{ "key": "Retweets" ,"yAxis": 2 , "type": "line", "values": ['
          favorites = '{ "key": "Favorited" ,"yAxis": 2 , "type": "line", "values": ['
          total_views, total_retweets, total_favorites = 0, 0 ,0
          delta = 3
          reduction = delta
          hour = start_time
          end_time = start_time + 48.hours
          if end_time > today_time
            end_time = today_time
          end
          while hour < today_time
            index = days.index hour
            if !index.nil?
              current_value = rand(0..max)
              total_views += current_value 
              if hour >= chart_start           
                daily << "[ #{hour.to_i}, #{current_value} ]"
                total << "[ #{hour.to_i}, #{total_views} ]"
                if days[index] != days.last
                  daily << ", "
                  total << ", "
                end
              end
            end
            if hour < end_time
              current_value = rand((max-reduction*2)..(max-reduction))
              total_retweets += current_value
              reduction += delta
              current_value1 = rand(0..max)
              total_favorites += current_value1
              if hour >= chart_start
                retweets << "[ #{hour.to_i}, #{current_value} ]"          
                favorites << "[ #{hour.to_i}, #{current_value1} ]"
                if hour < end_time - 1.hour
                  retweets << ", "
                  favorites << ", "
                end
              end
            end
            hour += 1.hour
          end
          if display_in_all
            all << daily << "]"
          end
          if release != releases.last
            if display_in_all
              all << "} , "
            end
          else 
            all << "}]"                     # Close the json object
          end
          if release == distribution
            views_json << daily << "]}, " << total << "]}," << retweets << "]}," << favorites << "]}]"
            data[:views_json] = views_json
            data[:views] = total_views
            data[:retweets] = total_retweets
            data[:favorited] = total_favorites
            data[:delivered] = rand(85..100)
            data[:refluencers] = release.influencers
          end
        end
        data[:all_json] = all
      end
      return data
    end

=begin
  def create_single_data release, days
    if @actives.nil?
      @actives = Release.where(brand_id: @brand.id, isTemplate: false, status: Release.statuses[:active])
    end
    if release.nil?
      if @actives.any?
        release = @actives.first 
      end
    end
    data = {set: nil, refluencers: 0, delivered:0, views: 0, retweets: 0, favorited: 0, views_json: "{}", retweets_json: "{}", favorited_json: "{}"}
    if !release.nil?
      today = Time.now.to_date
      start_date = release.distribution.start_date.to_date
      if start_date < today
        data[:set] = true
        max = 300
        if days != 69
          chart_date = today - days
        else
          chart_date = start_date
        end
        if chart_date < start_date
          start = chart_date
        else
          start = start_date
        end
        # Create the data for the views json
        views_json = "["
        daily = '{ "id": ' << "#{release.id}" << ' , "days": ' << "#{days}" << ', "key": "' << release.short_name << '" , "values": ['
        total = '{ "key": "Cumulative Views" , "values": ['
        total_value = 0
        start.upto today do |day|
          current_value = 0
          if day >= start_date
            current_value = rand(0..max)
            total_value += current_value
          end
          if day >= chart_date
            daily << "[ #{day.to_time.to_i}, #{current_value} ]"
            total << "[ #{day.to_time.to_i}, #{total_value} ]"
            if day != today
              daily << ", "
              total << ", "
            end
          end
        end
        views_json << daily << "]}, " << total << "]}]"
        data[:views_json] = views_json
        data[:views] = total_value
        data[:delivered] = rand(85..100)
        data[:refluencers] = release.influencers
        # End of create data for views json

        # Start of create data for retweets
        hourly = '[{ "key": "Retweets", "values": ['
        hour = release.distribution.start_date
        end_time = hour + 48.hours
        delta = 3
        reduction = delta
        total_value = 0
        while hour < end_time
          current_value = rand((max-reduction*2)..(max-reduction))
          total_value += current_value
          hourly << "[ #{hour.to_i}, #{current_value} ]"
          if hour != end_time - 1.hour
            hourly << ", "
          end
          hour += 1.hour
          reduction += delta
        end
        hourly << "]}]"
        data[:retweets_json] = hourly
        data[:retweets] = total_value
        # End of create data for retweets

        # Start of create data for favorited
        hourly = '[{ "key": "Favorited", "values": ['
        hour = release.distribution.start_date
        end_time = hour + 48.hours
        total_value = 0
        while hour < end_time
          current_value = rand(0..max)
          total_value += current_value
          hourly << "[ #{hour.to_i}, #{current_value} ]"
          if hour != end_time - 1.hour
            hourly << ", "
          end
          hour += 1.hour
        end
        hourly << "]}]"
        data[:favorited_json] = hourly
        data[:favorited] = total_value
        # End of create data for favorited
      end
    end
    return data
  end
=end
  def create_fake_data_per_release(type,days_before)
    if @releases.nil?
      @releases = @brand.releases.where(isTemplate: false) # Only look at active releases
    end
    if @actives.nil?
      @actives = @releases.where(status: Release.statuses[:active])
    end
    date = Time.now.to_date - days_before       # Get the lower end of date range
    today = Time.now.to_date                    # Get the high end of date range
    max = 300                                   # Max used for random generation
    id = -1                                     # set the id of type sent
    if !type.nil? # If type is nil then look at all active releases
      id = type
      rels = @actives.where(retype: type)   # Search based on current type
    else
      rels = @actives                       # Otherwise just use all of them
    end

    releases = []
    if days_before == 69  && rels.any?       # Reset the days for all
      lowest = rels.first.distribution.start_date
      rels.each do |release|
        if release.distribution.start_date < lowest
          lowest = release.distribution.start_date
        end
        if release.distribution.start_date <= Time.now
          releases.push(release)
        end
      end
      date = lowest.to_date
      range = date - Time.now.to_date
      days_before = range.to_i
    else
      rels.each do |release|
        if release.distribution.start_date <= Time.now
          releases.push(release)
        end
      end
    end

    data_json = "{}"                            # empty set if there is no data
    # Set the basic data hash for all analyitcs
    data = {set: nil, avg: 0,max: 0,min: max, total: 0, count: 0, reach: 0, relevance: 0, share_avg: 0, share_total: 0, mention_avg: 0, mention_total: 0}
    data[:influencers] = 0                   # Fake the data for influencers and social sources
    releases.each do |active|
      data[:reach] = data[:reach] + active.reach
      data[:relevance] = data[:relevance] + active.relevance
      data[:influencers] = data[:influencers] + active.influencers
    end
    if !releases.empty?
      data[:reach] = data[:reach]/releases.count
      data[:relevance] = data[:relevance]/releases.count
    end
    first = rand(0..100)
    second = rand(0..(100-first))
    third = 100-first-second
    data[:sources] = {"Social"=> first,"SEO" => second,"PPC" => third}
    data[:source_data] = "[#{first},#{second},#{third}]"
    if !releases.empty?
      total_value = 0                 # Total number of page views for all days and releases
      total_shares = 0
      total_mentions = 0
      releases.each do |release|      # We have some releases so set the json up
        if release == releases.first
          data[:set] = 1              # Tell the page data is set for data below graph
          data_json = '[{"days": ' << "#{days_before}" << ', "key": "' << "#{release.short_name}" << '" , "values": ['
        else 
          data_json << '{ "key": "' << "#{release.short_name}" << '" , "values": ['
        end                       
        date.upto today do |day|                # Loop through the dates to get data for
          if day >= release.distribution.start_date.to_date
            current_value = rand(1..max)          # Current value for this release for this day
            current_share = rand(0..10)
            current_mention = rand(0..20)
          else
            current_value = 0
            current_share = 0
            current_mention = 0
          end
          total_shares += current_share
          total_mentions += current_mention
          total_value +=  current_value         # Add that to the total
          # Set the values 
          if data[:max] < current_value         # Is this the biggest value
            data[:max] = current_value          # Set it and forget it
          end
          if data[:min] > current_value         # Is this the smallest value
            data[:min] = current_value            # Set it and forget it
          end
          data[:count] += 1                     # Add one to count for each day
          data_json << "[ #{day.to_time.to_i}, #{current_value}, #{current_share}, #{current_mention} ]" # Set the data for that day
          if day != today                       # We have more if it's not today
            data_json << ", "                   # Link the arrays
          else
            data_json << "]"                    # Otherwise close outer array
          end
        end
        if release != releases.last
          data_json << "} , "
        else 
          data_json << "}]"                     # Close the json object
        end
      end
      data[:total] = total_value                # Set the total number of page views
      data[:share_total] = total_shares
      data[:mention_total] = total_mentions
      data[:avg] = 0
      data[:share_avg] = 0
      data[:mention_avg] = 0
      if data[:count] != 0
        data[:avg] = data[:total]/data[:count]    # Set the average
        data[:share_avg] = data[:share_total]/data[:count]
        data[:mention_avg] = data[:mention_total]/data[:count]
      end
      #data_json << "}]"                         
    end
    data[:json] = data_json                     # Add it to the data hash
    return data
  end
end
