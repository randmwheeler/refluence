class Audience < ActiveRecord::Base
	extend FriendlyId
	friendly_id :name, use: [:slugged,:finders]
	validate :create_name
	validates_presence_of :name
	belongs_to :brand
	has_one :release
	belongs_to :industry
	belongs_to :subindustry
	validate :industry_valid_on_update
	validate :subindustry_valid_on_update

	private
		# This will create a default name if none supplied
		# 	This must be called after object creation otherwise id will be nil
		# If name is nil or blank the name will be Release #(id)
		def create_name
			new_name = false
			if self.name.nil?
				new_name = true
			elsif self.name == ""
				new_name = true
			end
			if new_name
				if self.id.nil?
					last = Audience.last
					if last.nil?
						next_id = 1
					else
						next_id = last.id + 1
					end
				else
					next_id = self.id
				end
				self.name = "Audience #{next_id}"
			end
		end

		def industry_valid_on_update
			if !self.id.nil?
				if self.industry.nil?
					errors.add(:industry, "must have an industry on update")
				end
			end
		end

		def subindustry_valid_on_update
			if !self.id.nil?
				if self.subindustry.nil?
					errors.add(:subindustry, "must have a subindustry on update")
				end
			end
		end
end
