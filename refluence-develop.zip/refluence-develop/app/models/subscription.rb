class Subscription < ActiveRecord::Base
	has_many :users

	PLANS = [Stripe::Plans::SMALL, Stripe::Plans::SMALL_YEAR, Stripe::Plans::MEDIUM, Stripe::Plans::MEDIUM_YEAR, Stripe::Plans::LARGE, Stripe::Plans::LARGE_YEAR]

	def small
		self.delegates = 0
		self.audiences = 3
		self.active_releases = 10
		self.agencies = 1
		self.brands = 3
		self.social_accounts = 3
		self.level = 0
	end

	def medium
		self.delegates = 2
		self.audiences = 10
		self.active_releases = 25
		self.agencies = 1
		self.brands = 10
		self.social_accounts = 10
		self.level = 1
	end

	def large
		self.delegates = 4
		self.audiences = 20
		self.active_releases = 50
		self.agencies = 3
		self.brands = 25
		self.social_accounts = 25
		self.level = 2
	end
end
