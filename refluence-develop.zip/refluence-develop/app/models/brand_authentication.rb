class BrandAuthentication < ActiveRecord::Base
  belongs_to :brand
  belongs_to :identity
  validates_presence_of :brand, :identity, :retype

  enum retype: {"Twitter" => 0, "Eden" => 1}

    # Definition of enum type for rails admin
  def retype_enum
  	['Twitter','Eden']
  end
end
