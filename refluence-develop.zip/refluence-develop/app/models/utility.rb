class Utility
	require 'csv'

	def self.clean_array(array)
		array.delete ""
		ret = []
		array.each do |some|
			ret.push(some.to_i);
		end
		return ret
	end

	def self.cap(string)
		string.split.map(&:capitalize).join(" ")
	end

	# Create a list of example twitter handles
	# => file_name will be where the file of csv twitter handles will be stored
	# => max is the number of twitter handles you wish to generate
	def self.create_example_csv(file_name,max,make_invalid_entries)
		count = 0				# Start of count
		array = []				# Array to store the handles
		while count < max do	# Go from 0 to 300
			handle = rand(36**rand(15)).to_s(36)# Makes a random string of upto 15 characters (a-z0-9)
			what = rand(9)		# Used to determine kind of error to create or used to add underscore
			case what			# Make about 33 percent invalid
			when 7 				# Make it too long
				if make_invalid_entries # Do we need to make invalid entries to test
					while handle.length < 15 do
						handle << handle
					end
				end
			when 8 				# Add invalid character
				if make_invalid_entries
					index = rand(handle.length)
					handle[index] = '*'
				end
			when 9 				# Make it too short
				if make_invalid_entries
					handle = ""
				end
			when 5,6 			# Add an underscore
				index = rand(handle.length)
				handle[index] = "_"
			end
			index = array.index handle 	# Make sure we don't put 2 of the same in the array
			if index.nil? 				# It's not in the array
				array.push(handle)		# Add to the array
				count = count + 1 		# now go to next one
			end
		end
		CSV.open(file_name, "w") do |csv|
			csv << array 
		end
	end
end