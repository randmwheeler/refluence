class Help < ActiveRecord::Base
  validates_presence_of :name, :content

  enum retype: {releases: 0, audiences: 1}

  # Definition of enum type for rails admin
  def retype_enum
  	['releases','audiences']
  end

  rails_admin do 
  	edit do
  		field :name
  		field :content, :ck_editor
  		field :video 
  		field :retype
  	end
  end
end
