# -*- coding: utf-8 -*-
class Subindustry < ActiveRecord::Base
  belongs_to :industry
  has_many :audiences
  has_many :industry_recommendations
  validates_presence_of :name, :industry
  validate :cap_words
  
  def canonical_name
    "#{industry.name} → #{name}"
  end

  private
  def cap_words
    if !self.name.nil?
      if !self.name.empty?
        self.name = Utility.cap(self.name)
      end
    end
  end
end
