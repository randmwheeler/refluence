class Content < ActiveRecord::Base
	belongs_to :release
	validate :remove_script_injection
	validate :headline_on_update

	def display_assets
		if self.assets.nil?
			assets = []
		else
			assets = ActiveSupport::JSON.decode(self.assets)
		end
		images = ''
		if !assets.empty?
			images = '<div class="row">'
			assets.each do |i|
				image = AgencyImage.find_by(id: i)
				if !image.nil?
					images << '<div class="col-xs-12 col-md-12">'
					if !image.image_content_type.match(/image/).nil?
						images << "<img alt='#{image.image_file_name}' class='img-responsive' src='#{image.image.url}'>"
					else
						images << '<a href="' << image.image.url << '">' << image.image_file_name << '</a>'
					end
					images << '</div><div class="paddington">&nbsp;</div>'
				end
			end
			images << '</div>'
		end
		return images.html_safe
	end

	private
		# This will remove any javascript inject for the html copy
		# First remove just anything from script start to script end tag
		# Or remove javascript: directive in a tag
		# Or any iframe
		def remove_script_injection
			if !self.copy.nil?
				fixed_copy = self.copy
				fixed_copy = fixed_copy.gsub(/<script.*?>[\s\S]*<\/script>/i,"")
				fixed_copy = fixed_copy.gsub(/javascript:/,"")
				fixed_copy = fixed_copy.gsub(/<iframe(\w|\s|\d|=|'|"|:|\/|.)*><\/iframe>/,"")
				self.copy = fixed_copy
			end
		end

		def headline_on_update
			valid = true
			if !self.id.nil?
				if !self.headline.nil?
					if self.headline.empty?
						valid = false
					end
				else
					valid = false
				end
			end
			if !valid 
				errors.add(:headline, "can't be blank")
			end
		end
end
