class Authentication < ActiveRecord::Base
	extend FriendlyId
	friendly_id :name, use: [:slugged,:finders]
	belongs_to :user

	def name
		"#{user.email}-#{provider}-#{uid}"
	end
end
