class Distribution < ActiveRecord::Base
  	belongs_to :release
  	validate :start_before_end

  	private
		# This will probably not be needed but is a simple check
		# 	for start being before end
		def start_before_end
			if !self.start_date.nil?
				if !self.end_date.nil?
					if self.end_date <= self.start_date
						errors.add(:start_date, "must be before end date")
					end
				end
				if !self.release.isTemplate
					max_end = Time.now.to_date - 1.month
					if self.start_date.to_date < max_end
						errors.add(:start_date, "can't be in the past")
					end
					if self.start_date_changed?
						self.end_date = self.start_date + 365.days
					end
				end
			end
		end
end
