class User < ActiveRecord::Base
	TEMP_EMAIL_PREFIX = 'change@me'
  	TEMP_EMAIL_REGEX = /\Achange@me/
	extend FriendlyId
	friendly_id :slug_candidates, use: [:slugged,:finders]
	# Include default devise modules. Others available are:
	#
	devise :database_authenticatable, :registerable, :confirmable, :omniauthable,
	     :recoverable, :rememberable, :trackable, :validatable, :lockable, :timeoutable

	enum role: {admin: 0, user: 1}
	enum state: {normal: 0, add_social: 1, add_asset: 2, add_logo: 3}

	def state_enum
		[:normal,:add_social,:add_asset,:add_logo]
	end

	validates_presence_of :email, :name#, :family_name, :organization, :title, :code
	validates_format_of :email, :without => TEMP_EMAIL_REGEX, on: :update
	validate :has_beta_code
	# mount_uploader :image, ImageUploader
  	has_many :identities
	after_save :set_agency
	after_initialize :set_default_role, if: :new_record?

	has_many :authentications
	has_many :agencies

	belongs_to :subscription
	belongs_to :brand

	before_destroy :destroy_associated_content


	def role_enum
		[:admin,:user]
	end

	# Try build a slug based on the following fields in increasing order of specifity
	def slug_candidates
		[
			[:name,:family_name],
			[:name,:family_name,:email]
		]
	end

	# Make sure that the slug changes when the name or email changes
	def should_generate_new_friendly_id?
		name_changed? || family_name_changed? || email_changed?
	end

	# Fake stuff to make simple form shut up
	def email_confirmation
	end

	def full_name
		"#{self.name} #{self.family_name}"
	end

	# This will set the default role to a user if role is not already sets
	def set_default_role
		self.role ||= :user
	end

	# Add more code here to get all brands a user has access to
	def brands
		if !self.agencies.empty?
			return Brand.where(agency_id: self.agencies)
		else
			return []
		end
	end

	def self.find_for_oauth(auth, signed_in_resource = nil)

		# Get the identity and user if they exist
		identity = Identity.find_for_oauth(auth)
		#identity = Identity.where(provider: auth.provider, uid: auth.uid.to_s, token: auth.credentials.token, secret: auth.credentials.secret).first_or_initialize

		# If a signed_in_resource is provided it always overrides the existing user
		# to prevent the identity being locked with accidentally created accounts.
		# Note that this may leave zombie accounts (with no associated identity) which
		# can be cleaned up at a later date.
		# user = signed_in_resource ? signed_in_resource : identity.user

		user = signed_in_resource.nil? ? User.find_by(email: auth['info']['email']) : signed_in_resource

		if !user.brand_id.nil?
			BrandAuthentication.find_or_create_by(brand_id: user.brand_id, identity_id: identity.id, permission: true,
				retype: BrandAuthentication.retypes[identity.provider.capitalize])
		end

		# Create the user if needed
		if user.nil?

		# if user.blank?

		  # Get the existing user by email if the provider gives us a verified email.
		  # If no verified email was provided we assign a temporary email and ask the
		  # user to verify it on the next step via UsersController.finish_signup
		  email_is_verified = auth.info.email && (auth.info.verified || auth.info.verified_email)
		  email = auth.info.email if email_is_verified
		  user = User.find_by(email: email) if email

		  # Create the user if it's a new registration
		  if user.nil?
		  	user = User.find_by(email: "#{TEMP_EMAIL_PREFIX}-#{auth.uid}-#{auth.provider}.com")
		  	if user.nil?
		        user = User.new(
		          name: auth.info.name,
		          email: auth.info.email ? auth.info.email : "#{TEMP_EMAIL_PREFIX}-#{auth.uid}-#{auth.provider}.com",
		          password: Devise.friendly_token[0, 20]
		        )
		        auth.provider == "twitter" ? user.save!(validate: false) : user.save!
		    end
		  end
		  identity.username = auth.info.nickname
		  identity.user_id = user.id
		end

		# Associate the identity with the user if needed
		if identity.user != user
		  identity.user = user
		  identity.save!
		end
		identity.user
	end

  def email_verified?
    self.email && self.email !~ TEMP_EMAIL_REGEX
  end

	private

		def has_beta_code
			found = BetaAccount.find_by(email: self.email)
			if found.nil?
				errors.add(:code, "has not signed up for beta account yet.")
			else
				if found.code != self.code 
					errors.add(:code, "doesn't match the existing beta account code.")
				else
					been_used = false
					if found.used.nil?
						been_used = true
					else
						if !found.used
							been_used = true
						end
					end
					if been_used
						found.update_column(:used, true)
					end
				end
			end
		end

		def set_agency
			ag = Agency.find_by(user_id: self.id)
			# No agency so let's make one
			if ag.nil?
				ag = Agency.create(name: self.organization,user_id: self.id)
			else
				# If our organization has updated let's update the agency
				if ag.name != self.organization
					ag.name = self.organization
					ag.slug = nil
					ag.save
				end
			end
		end

		def destroy_associated_content
			# User has agencies and identites -> agencies have brands and images -> brands have releases and identites
			#	-> releases have content, audience, distribution, and contact
			self.agencies.each do |agency|
				agency.brands.each do |brand|
					brand.releases.each do |release|
						release.destroy
					end
					# Destroy all the brand identities
					auths = BrandAuthentication.where(brand_id: brand.id)
					auths.each do |auth|
						auth.destroy 
					end
					# Destroy the brand
					brand.destroy 
				end
				# Destroy all the images
				images = AgencyImage.where(agency_id: agency.id)
				images.each do |image|
					image.destroy 
				end
				# Destroy the agency
				agency.destroy
			end
			# Destroy the identities
			idens = Identity.where(user_id: self.id)
			idens.each do |iden|
				iden.destroy 
			end
			# Make sure to convert all releases they created to the agency owner
			releases = Release.where(creator_id: self.id)
			releases.each do |release|
				owner = release.brand.agency.user
				release.creator = owner
				release.save
			end

			# Make sure to delete their beta account as well
			beta = BetaAccount.find_by(email: self.email.downcase)
			if !beta.nil?
				beta.destroy
			end
		end
end
