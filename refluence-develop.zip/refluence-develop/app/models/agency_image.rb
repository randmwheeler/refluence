class AgencyImage < ActiveRecord::Base
  belongs_to :agency
  has_attached_file :image,
                    :storage => :s3,
                    :s3_credentials => Proc.new{ |a| a.instance.s3_credentials }
#, :styles => { :medium => "300x300>", :thumb => "100x100>" }, :default_url => "/images/:style/missing.png"
  # Validate content type
  validates_attachment_content_type :image, :content_type => ['image/jpeg', 'image/pjpeg',
                                  'image/jpg', 'image/png', 'image/tif', 'image/gif', 'application/vnd.ms-works',
                                  'application/pdf', 'application/msword', 'text/plain', 'text/rtf', 'application/postscript',
                                  'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.ms-office',
                                  "application/vnd.ms-excel", "application/excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                  'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                                  'video/quicktime', 'video/mp4', 'video/mpeg',  'video/3gpp2', 'video/3gpp',
                                  'audio/mpeg' ], :message => "has to be in a proper format "
  # Validate filename
  #validates_attachment_file_name :image, :matches => [/png\Z/, /jpe?g\Z/, /gif\Z/]
  validates_presence_of :image

  def s3_credentials
    {
      bucket: Rails.application.secrets.amazon_s3_assets_bucket_name,
      access_key_id: Rails.application.secrets.amazon_s3_assets_bucket_key.to_s,
      secret_access_key: Rails.application.secrets.amazon_s3_assets_bucket_secret.to_s
    }
  end
end