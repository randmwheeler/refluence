class Contact < ActiveRecord::Base
	belongs_to :release
	#validate :valid_name
	validate :valid_phone
	validate :valid_fax
	validate :valid_email

	private
		def valid_name
			if !self.id.nil?
				if self.name == ""
					errors.add(:name, "can't be blank")
				end
			end
		end

		def valid_phone
			if !self.id.nil?		# Only validate on update
				if self.phone != "" # Only validate when they have entered a phone number
					number = GlobalPhone.parse(phone)
					valid = false
					if !number.nil?
						if number.valid?
							valid = true
						end
					end
					if !valid
						errors.add(:phone, "is not a valid format")
					end
				end
			end
		end

		def valid_fax
			if !self.id.nil?		# Only validate on update
				if self.fax != "" # Only validate when they have entered a phone number
					number = GlobalPhone.parse(fax)
					valid = false
					if !number.nil?
						if number.valid?
							valid = true
						end
					end
					if !valid
						errors.add(:fax, "is not a valid format")
					end
				end
			end
		end

		def valid_email
			if !self.id.nil?
				if self.email != ""
					match = self.email.match(/\A[\w+\-.]+@[a-z\d\-]+(\.[a-z]+)*\.[a-z]+\z/i)
					if match.nil?
						errors.add(:email, "is not a valid format")
					end
				end
			end
		end
end
