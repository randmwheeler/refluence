class BetaAccount < ActiveRecord::Base
	validates_presence_of :email, :name
	validate :create_code
	validate :email_exists

	private
		def create_code
			if self.code.empty?
				self.code = Digest::SHA1.hexdigest "#{Time.now}"
				existing = BetaAccount.find_by(code: code)
				while existing != nil
					self.code = Digest::SHA1.hexdigest "#{Time.now}"
					existing = BetaAccount.find_by(code: code)
				end
			end
		end

		def email_exists
			if !self.email.nil?
				self.email = self.email.downcase # Make sure to lowercase all email addresses
			end
			beta = BetaAccount.find_by(email: email)
			if !beta.nil?
				user = User.find_by(email: email)
				if !user.nil?
					errors.add(:base, "This email already has an account please login.")
				else
					errors.add(:base, "There has already been a beta code requested for this email.")
				end
			end
		end
end
