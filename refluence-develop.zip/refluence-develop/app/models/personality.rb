class Personality < ActiveRecord::Base
	extend FriendlyId
	friendly_id :name, use: [:slugged,:finders]
	belongs_to :brand
	belongs_to :authentication

	def name
		"#{brand.name}-#{authentication.name}"
	end
end
