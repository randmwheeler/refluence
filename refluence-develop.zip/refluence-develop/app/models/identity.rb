class Identity < ActiveRecord::Base
  belongs_to :user
  has_and_belongs_to_many :brands
  after_create :fetch_details
  validates_presence_of :uid, :provider
  # validates_uniqueness_of :uid, scope: :provider

  def self.find_for_oauth(auth)
    identity = find_by(provider: auth.provider, uid: auth.uid)
    identity = create(uid: auth.uid, provider: auth.provider) if identity.nil?
    identity.set_username(auth) if identity.username.blank?
    identity.set_token(auth) if identity.token.blank?
    identity.set_secret(auth) if identity.secret.blank?
    identity
  end

  def fetch_details
    self.send("fetch_details_from_#{self.provider.downcase}")
  end

  def fetch_details_from_twitter
  end

  def set_username(auth)
    if auth.provider == "twitter"
      self.update_column(:username,auth["info"]["nickname"])
    end
  end

  def set_token(auth)
    if auth.provider == "twitter"
      self.update_column(:token,auth["credentials"]["token"])
    end
  end

  def set_secret(auth)
    if auth.provider == "twitter"
      self.update_column(:secret,auth["credentials"]["secret"])
    end
  end
end
