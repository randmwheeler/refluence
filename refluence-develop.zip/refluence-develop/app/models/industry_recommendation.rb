class IndustryRecommendation < ActiveRecord::Base
  belongs_to :subindustry
  validates_presence_of :subindustry, :numeric_id

  def spare_me
  end

  def load_from_correlate
    tries = 3
    begin
      res = JSON.parse open( "http://refluence.correlate.io:80/api/v1/sources?type=TwitterPublic&accountid=#{numeric_id}&apikey=#{Rails.application.secrets.correlate_key}" ).read
      res = res.try :[], 0 # returns a one element array
      
      raise KeyError, "No profile for #{numeric_id}" if not profile = res.try( :[], 'profile' )

      self.source_id = res['id']
      self.handle = profile['screen_name']
      self.profile_image_url = profile['profile_image_url']
      self.name = profile['name']
      self.tweet_count = profile['statuses_count']
      self.listed_count = profile['listed_count']
      self.follower_count = profile['followers_count']
      self.following_count = profile['friends_count']
      self.favorites_count = profile['status'].try( :[], 'favorite_count' )
      save!
    rescue Errno::ECONNREFUSED
      puts "Account Metadata Connection Refused: #{numeric_id}"
      retry if ( tries -= 1 ) > 0
      raise IOError, "Connection refused #{times} #{'time'.pluralize times}"
    rescue OpenURI::HTTPError => err
      raise IOError, err
    end
  end
end
