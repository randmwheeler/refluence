class Industry < ActiveRecord::Base
  has_many :subindustries
  has_many :audiences
  validates_presence_of :name
  validate :cap_words

  private
  def cap_words
    self.name = Utility.cap( self.name ) if self.name and self.name.present?
  end
end

