class Brand < ActiveRecord::Base
	extend FriendlyId
	friendly_id :slug_candidates, use: [:slugged,:finders]
	validates_presence_of :name, :agency
	belongs_to :agency
	has_many :releases
	has_many :audiences
	has_many :personalities
	has_and_belongs_to_many :identities
	validate :same_name

	def full_name
		"#{self.agency.name} - #{self.name}"
	end

	def brand_id
	end

	# Try build a slug based on the following fields in increasing order of specifity
	def slug_candidates
		[
			:name,
			[:name,"#{self.agency.slug}"]
		]
	end

	private
		def same_name
			brands = self.agency.brands
			brands.each do |brand|
				if self.name == brand.name 	# We have the same name
					if self.id != brand.id 	# And it's not the current brand
						errors.add(:name,"can't have the same name as an existing brand for the same agency.")
					end
				end
			end
		end
end
