class Agency < ActiveRecord::Base
	extend FriendlyId
	friendly_id :slug_candidates, use: [:slugged,:finders]
	validates_presence_of :name, :user
	validate :user_has_multiple_agencies
	has_many :brands
	belongs_to :user

	# Try build a slug based on the following fields in increasing order of specifity
	def slug_candidates
		[
			:name,
			[:name,:user]
		]
	end

	# Make sure that the slug changes when the name or user changes
	def should_generate_new_friendly_id?
		name_changed? ||  user_id_changed?
	end

	# Creating assets
	def assets
		$assetsBox["/#{id}/"].to_dir
	end

	# Creating campaigns
	def campaigns
		$campaignsBox["#{id}/"].to_dir
	end

	private
		# Make sure that the current name isn't the same as an existing name for this user
		def user_has_multiple_agencies
			if !self.name.nil?
				self.name = Utility.cap(self.name)
			end
			other = Agency.find_by(user_id: self.user_id, name: self.name)
			if !other.nil?					# We found another one
				if other.id != self.id 		# And they aren't the same
					errors.add(:name, "can't have an agency with the same name for the same user.")
				end
			end
=begin
			other = Agency.find_by(user_id: self.user_id)
			if !other.nil?
				if other.id != self.id
					errors.add(:base, "User can't have more than one agency associated directly.")
				end
			end
=end
		end
end