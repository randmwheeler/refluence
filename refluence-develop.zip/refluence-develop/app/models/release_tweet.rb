class ReleaseTweet < ActiveRecord::Base
  belongs_to :release
end
