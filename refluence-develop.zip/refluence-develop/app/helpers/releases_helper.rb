module ReleasesHelper
  def display_assets(release)
    assets = []
    if !release.content.nil?
      if !release.content.assets.nil?
        assets = ActiveSupport::JSON.decode(release.content.assets)

        images = '<div class="row">'
        assets.each do |i|
          image = AgencyImage.find_by(id: i)
          if !image.nil?
            images << '<div class="col-xs-12 col-md-12">'
            if !image.image_content_type.match(/image/).nil?
              images << image_tag( image.image.url, class: "img-responsive")
            else
              images << '<a href="' << image.image.url << '">' << image.image_file_name << '</a>'
            end
            images << '</div><div class="paddington">&nbsp;</div>'
          end
        end
        images << '</div>'
      end
    end
    images.try(:html_safe) || ''
  end

  def is_now(release)
    if !release.distribution.nil?
      if !release.distribution.start_date.nil?
        if release.distribution.start_date <= Time.now 
          return "<strong>For immediate release</strong>".html_safe
        else
          return ""
        end
      end
    end
    return ""
  end

  def shorten_number number
    #return if not number
    what = ""
    if !number.nil?
      if number.is_a? Numeric
        what = number_to_human(number, significant: true, precision: 3).gsub(/ /,'').upcase
        what.gsub!(/THOUSAND/,"K")
        what.gsub!(/MILLION/,"M")
        what.gsub!(/BILLION/,"B")
      end
    end
    return what
  end
end
