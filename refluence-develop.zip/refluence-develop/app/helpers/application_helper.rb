module ApplicationHelper

  def display_base_errors resource
    return '' if (resource.errors.empty?) or (resource.errors[:base].empty?)
    messages = resource.errors[:base].map { |msg| content_tag(:p, msg) }.join
    html = <<-HTML
    <div class="alert alert-error alert-block">
      <button type="button" class="close" data-dismiss="alert">&#215;</button>
      #{messages}
    </div>
    HTML
    html.html_safe
  end

  # Function to determine if the body of a page needs to be dark
  def is_dark_path path 
    # List of all paths where the dark pattern is needed
    dark_paths = [root_path, new_user_session_path, user_session_path, login_path,
                  user_password_path, new_user_password_path, user_registration_path,
                  new_user_registration_path, select_dashboard_path, select_brands_path,
                  new_brand_path, create_account_path, select_subscription_path, recover_password_path,
                  pages_index_path, pages_our_story_path, pages_pricing_path, pages_how_it_works_path,
                  pages_investor_information_path, pages_help_and_support_path, pages_faqs_path,
                  pages_our_team_path, pages_contact_path, pages_about_path, user_confirmation_path,
                  agencies_path, new_agency_path, downgrade_path]
    index = dark_paths.index path # Let's see if the current path is in the array
    if index.nil?     # It wasn't so we don't need it
      return false
    else              # It was so we do need it
      return true
    end
  end

  # Function to determine if the navbar needs to be displayed
  def has_navbar path 
    if path == root_path  # If we are on the home page go ahead and display it
      return true
    end
    if user_signed_in?    # If we are signed in let's check if we need it
      # Array of pages that don't need a navbar
      no_navbar_paths = [new_brand_path, select_dashboard_path, select_subscription_path]
      index = no_navbar_paths.index path # Let's see if the current path is in that array
      if index.nil?       # If it wasn't then we do need to display it
        return true
      else                # Otherwise don't display it
        return false
      end
    else                  # We aren't logged in so don't display the navbar
      navbar_paths = [pages_index_path, pages_our_story_path, pages_pricing_path, pages_how_it_works_path,
                  pages_investor_information_path, pages_help_and_support_path, pages_faqs_path,
                  pages_our_team_path, pages_contact_path, pages_about_path] # Signed out paths with navbar
      index = navbar_paths.index path
      if index.nil?       # The path wasn't in the list so no navbar
        return false
      else                # The path was in the list so show the navbar
        return true
      end
    end
  end

  # Function to determine if the help sidebar needs to be displayed
  def has_sidebar path 
    if user_signed_in?  # Only need to display the sidebar for logged in users
      # That are not in this array
      no_sidebar_paths = [new_brand_path, select_dashboard_path, root_path, select_subscription_path]
      index = no_sidebar_paths.index path # Let's see if the current path is in the array
      if index.nil?     # If it wasn't then we do need to display it
        if !path[/\/view\z/].nil? # Unless path ends with /view
          return false
        else
          return true
        end
      else              # Otherwise we don't                   
        return true
      end
    else                # And we don't need to display it for guests
      return false
    end
  end

  def has_notice con, path
    if path == root_path
      return true
    end
    if user_signed_in?
      if path != root_path
        no_messages_paths = ["release","brand"]
        index = no_messages_paths.index con 
        if index.nil?
          return false
        else
          return true
        end
      end
    else
      return false
    end
  end

  def can_view user, sub 
    if user.nil?
      return false
    else
      if user.subscription != sub
        return true
      else
        return false
      end
    end
  end

  # Function to determine if a user can view the selected subscription div
  def subscription_level user
    if user.nil?
      return "none"
    else
      if !user.subscription.nil?
        return user.subscription.name
      else
        return "none"
      end
    end
  end

  def first_word sentence
    return sentence.split(' ')[0]
  end

  def plural string, number
    if number == 1
      return "#{number} " " #{string.singularize}"
    else
      return "#{number} " " #{string.pluralize}"
    end
  end

  def stripify price #changing price from format $123.45 to 12345 for stripe
    price.gsub(/[$.,]/, "")
  end
end
  
